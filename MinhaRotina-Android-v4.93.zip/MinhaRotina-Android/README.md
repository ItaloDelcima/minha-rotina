# Minha Rotina — Trem Bão
App de rotina (WebView) com widgets. Build via GitHub Actions (.github/workflows/build.yml) → artefato MinhaRotina-apk.
