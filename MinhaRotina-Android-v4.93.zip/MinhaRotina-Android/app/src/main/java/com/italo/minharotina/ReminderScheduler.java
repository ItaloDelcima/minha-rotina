package com.italo.minharotina;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Agenda notificações nativas (AlarmManager) a partir do JSON enviado pelo app. */
public class ReminderScheduler {
    static final String PREFS = "mr_notif";

    public static void schedule(Context c, String json) {
        SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        int prev = p.getInt("count", 0);
        for (int i = 0; i < prev; i++) { try { am.cancel(pi(c, i, null, null)); } catch (Exception ignored) {} }
        int n = 0;
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length() && n < 100; i++) {
                JSONObject o = arr.optJSONObject(i); if (o == null) continue;
                long at = o.optLong("at", 0); if (at <= now) continue;
                String title = o.optString("title", "Lembrete");
                String body = o.optString("body", "");
                PendingIntent piN = pi(c, n, title, body);
                try {
                    if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, piN);
                    else
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, piN);
                } catch (SecurityException se) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, piN);
                }
                n++;
            }
        } catch (Exception ignored) {}
        p.edit().putInt("count", n).putString("list", json == null ? "[]" : json).apply();
    }

    static PendingIntent pi(Context c, int id, String title, String body) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("mr.notif." + id);
        if (title != null) { i.putExtra("title", title); i.putExtra("body", body); }
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, id, i, f);
    }

    public static void reschedule(Context c) {
        schedule(c, c.getSharedPreferences(PREFS, 0).getString("list", "[]"));
    }
}
