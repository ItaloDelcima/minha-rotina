package com.italo.minharotina;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

public class RoutinesWidget extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.italo.minharotina.TOGGLE_ROUTINE";
    private static final int[] ROW = { R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4, R.id.row5 };
    private static final int[] CHK = { R.id.chk0, R.id.chk1, R.id.chk2, R.id.chk3, R.id.chk4, R.id.chk5 };
    private static final int[] NAME = { R.id.name0, R.id.name1, R.id.name2, R.id.name3, R.id.name4, R.id.name5 };

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) render(c, m, id); }

    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            String rid = intent.getStringExtra("rid");
            boolean want = intent.getBooleanExtra("want", true);
            if (rid != null) { toggle(c, rid, want); Widgets.updateAll(c); }
        }
    }

    private void toggle(Context c, String rid, boolean want) {
        SharedPreferences p = Widgets.prefs(c);
        try {
            JSONArray arr = new JSONArray(p.getString("routines", "[]"));
            for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && rid.equals(o.optString("id"))) { o.put("done", want); break; } }
            JSONArray pend = new JSONArray(p.getString("pending", "[]")); JSONArray next = new JSONArray();
            for (int i = 0; i < pend.length(); i++) { JSONObject o = pend.optJSONObject(i); if (o != null && !rid.equals(o.optString("id"))) next.put(o); }
            JSONObject nw = new JSONObject(); nw.put("id", rid); nw.put("done", want); next.put(nw);
            p.edit().putString("routines", arr.toString()).putString("pending", next.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void render(Context c, AppWidgetManager m, int widgetId) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_routines);
        int accent = Widgets.accent(c), text = Widgets.textColor(c), sub = Widgets.subColor(c);
        v.setInt(R.id.root, "setBackgroundResource", Widgets.bgRes(c));
        v.setTextColor(R.id.wTitle, text); v.setTextColor(R.id.wCount, accent); v.setTextColor(R.id.wFoot, sub);

        SharedPreferences p = Widgets.prefs(c);
        JSONArray arr; try { arr = new JSONArray(p.getString("routines", "[]")); } catch (Exception e) { arr = new JSONArray(); }
        int total = arr.length(), done = 0, shown = Math.min(total, ROW.length);
        for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && o.optBoolean("done")) done++; }
        v.setTextViewText(R.id.wCount, done + "/" + total);

        for (int i = 0; i < ROW.length; i++) {
            if (i < shown) {
                JSONObject o = arr.optJSONObject(i);
                String rid = o.optString("id"), emoji = o.optString("emoji", ""), name = o.optString("name", "");
                boolean isDone = o.optBoolean("done");
                v.setViewVisibility(ROW[i], View.VISIBLE);
                v.setTextViewText(CHK[i], isDone ? "☑" : "☐");
                v.setTextColor(CHK[i], isDone ? accent : sub);
                v.setTextViewText(NAME[i], (emoji.isEmpty() ? "" : emoji + " ") + name);
                v.setTextColor(NAME[i], isDone ? sub : text);
                Intent t = new Intent(c, RoutinesWidget.class);
                t.setAction(ACTION_TOGGLE); t.putExtra("rid", rid); t.putExtra("want", !isDone);
                v.setOnClickPendingIntent(ROW[i], PendingIntent.getBroadcast(c, ("t" + rid).hashCode(), t, Widgets.piFlags()));
            } else v.setViewVisibility(ROW[i], View.GONE);
        }
        if (total == 0) v.setTextViewText(R.id.wFoot, "Nenhuma rotina para hoje — abrir app");
        else if (total > shown) v.setTextViewText(R.id.wFoot, "+" + (total - shown) + " · abrir app");
        else v.setTextViewText(R.id.wFoot, "Abrir app");
        v.setOnClickPendingIntent(R.id.wFoot, Widgets.openAction(c, "hoje", 9001));
        v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, "hoje", 9002));
        m.updateAppWidget(widgetId, v);
    }
}
