package com.italo.minharotina;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class CustomWidget extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.italo.minharotina.CW_TOGGLE";
    static final String ACTION_CNT = "com.italo.minharotina.CW_CNT";
    static final String ACTION_EXP = "com.italo.minharotina.CW_EXP";
    private static final int[] LROW  = { R.id.lrow0, R.id.lrow1, R.id.lrow2, R.id.lrow3, R.id.lrow4, R.id.lrow5, R.id.lrow6, R.id.lrow7, R.id.lrow8, R.id.lrow9 };
    private static final int[] LCHK  = { R.id.lchk0, R.id.lchk1, R.id.lchk2, R.id.lchk3, R.id.lchk4, R.id.lchk5, R.id.lchk6, R.id.lchk7, R.id.lchk8, R.id.lchk9 };
    private static final int[] LNAME = { R.id.lname0, R.id.lname1, R.id.lname2, R.id.lname3, R.id.lname4, R.id.lname5, R.id.lname6, R.id.lname7, R.id.lname8, R.id.lname9 };
    private static final int[] SC  = { R.id.sc0, R.id.sc1, R.id.sc2, R.id.sc3, R.id.sc4, R.id.sc5 };
    private static final int[] SCI = { R.id.sc0i, R.id.sc1i, R.id.sc2i, R.id.sc3i, R.id.sc4i, R.id.sc5i };
    private static final int[] SCT = { R.id.sc0t, R.id.sc1t, R.id.sc2t, R.id.sc3t, R.id.sc4t, R.id.sc5t };
    private static final int[] ST  = { R.id.st0, R.id.st1, R.id.st2, R.id.st3 };
    private static final int[] STI = { R.id.st0i, R.id.st1i, R.id.st2i, R.id.st3i };
    private static final int[] STT = { R.id.st0t, R.id.st1t, R.id.st2t, R.id.st3t };

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) render(c, m, id); }

    @Override public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = Widgets.prefs(c).edit();
        for (int id : ids) { e.remove("cfg_" + id); e.remove("cnt_" + id); e.remove("exp_" + id); }
        e.apply();
    }

    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        String a = intent.getAction();
        if (ACTION_TOGGLE.equals(a)) {
            String rid = intent.getStringExtra("rid");
            boolean want = intent.getBooleanExtra("want", true);
            if (rid != null) { toggleRoutine(c, rid, want); Widgets.updateAll(c); }
        } else if (ACTION_CNT.equals(a)) {
            int wid = intent.getIntExtra("wid", -1);
            if (wid >= 0) {
                SharedPreferences p = Widgets.prefs(c);
                p.edit().putInt("cnt_" + wid, p.getInt("cnt_" + wid, 0) + 1).apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            }
        } else if (ACTION_EXP.equals(a)) {
            int wid = intent.getIntExtra("wid", -1);
            if (wid >= 0) {
                SharedPreferences p = Widgets.prefs(c);
                p.edit().putBoolean("exp_" + wid, !p.getBoolean("exp_" + wid, false)).apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            }
        }
    }

    private void toggleRoutine(Context c, String rid, boolean want) {
        SharedPreferences p = Widgets.prefs(c);
        try {
            JSONArray arr = new JSONArray(p.getString("routines", "[]"));
            for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && rid.equals(o.optString("id"))) { o.put("done", want); break; } }
            JSONArray pend = new JSONArray(p.getString("pending", "[]")); JSONArray next = new JSONArray();
            for (int i = 0; i < pend.length(); i++) { JSONObject o = pend.optJSONObject(i); if (o != null && !rid.equals(o.optString("id"))) next.put(o); }
            JSONObject nw = new JSONObject(); nw.put("id", rid); nw.put("done", want); next.put(nw);
            p.edit().putString("routines", arr.toString()).putString("pending", next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static JSONObject designFor(Context c, int widgetId) {
        SharedPreferences p = Widgets.prefs(c);
        String did = p.getString("cfg_" + widgetId, "");
        try {
            JSONArray arr = new JSONArray(p.getString("customWidgets", "[]"));
            if (!did.isEmpty()) for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && did.equals(o.optString("id"))) return o; }
            if (arr.length() > 0) return arr.optJSONObject(0);
        } catch (Exception ignored) {}
        return null;
    }

    static boolean night(Context c, JSONObject d) {
        String m = d != null ? d.optString("theme", "system") : "system";
        if ("light".equals(m)) return false;
        if ("dark".equals(m)) return true;
        int f = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return f == Configuration.UI_MODE_NIGHT_YES;
    }
    static int accentOf(Context c, JSONObject d) {
        if (d != null) { String col = d.optString("color", "accent"); if (!"accent".equals(col)) { try { return Color.parseColor(col); } catch (Exception e) {} } }
        return Widgets.accent(c);
    }

    private void render(Context c, AppWidgetManager m, int widgetId) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_custom);
        JSONObject d = designFor(c, widgetId);
        boolean night = night(c, d);
        int text = night ? 0xFFF2F2F5 : 0xFF1A1A1E, sub = night ? 0xFFAFAFB8 : 0xFF6A6A72, accent = accentOf(c, d);
        v.setInt(R.id.root, "setBackgroundResource", night ? R.drawable.bg_widget_dark : R.drawable.bg_widget_light);
        v.setTextColor(R.id.wTitle, text); v.setTextColor(R.id.wCount, accent);
        // esconde todos os blocos
        v.setViewVisibility(R.id.statBox, View.GONE); v.setViewVisibility(R.id.wPhrase, View.GONE);
        v.setViewVisibility(R.id.linesBox, View.GONE); v.setViewVisibility(R.id.scBox, View.GONE);
        v.setViewVisibility(R.id.metaBox, View.GONE); v.setViewVisibility(R.id.cntBox, View.GONE);
        v.setViewVisibility(R.id.twoBox, View.GONE); v.setViewVisibility(R.id.stripBox, View.GONE);
        v.setViewVisibility(R.id.wCount, View.GONE); v.setViewVisibility(R.id.wAdd, View.GONE);

        if (d == null) {
            v.setTextViewText(R.id.wTitle, "Widget Trem Bão");
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, sub);
            v.setTextViewText(R.id.wPhrase, "Abra o app › Widgets para criar um modelo.");
            v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, "widgets", 8600 + (widgetId % 300)));
            m.updateAppWidget(widgetId, v); return;
        }

        String type = d.optString("type", "list"), name = d.optString("name", "Widget"), icon = d.optString("icon", ""), source = d.optString("source", "routines");
        v.setTextViewText(R.id.wTitle, (icon.isEmpty() ? "" : icon + " ") + name);
        String openScr = "stat".equals(type) || "conquistas".equals(type) ? "pontos"
                : "financas".equals(type) ? "fin"
                : "agenda".equals(type) ? "hoje"
                : "meta".equals(type) ? "metas"
                : "nota".equals(type) ? "notas"
                : "reminders".equals(source) ? "lembretes" : "wishes".equals(source) ? "desejos" : "hoje";
        v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, openScr, 8600 + (widgetId % 300)));

        SharedPreferences p = Widgets.prefs(c);

        if ("stat".equals(type)) {
            v.setViewVisibility(R.id.statBox, View.VISIBLE);
            v.setTextColor(R.id.wStatBig, accent); v.setTextColor(R.id.wStatSub, sub);
            String kind = d.optString("statKind", "progress");
            v.setTextViewText(R.id.wStatBig, statValue(p, kind));
            v.setTextViewText(R.id.wStatSub, statLabel(kind));

        } else if ("financas".equals(type)) {
            v.setViewVisibility(R.id.statBox, View.VISIBLE);
            v.setTextColor(R.id.wStatBig, accent); v.setTextColor(R.id.wStatSub, sub);
            String fk = d.optString("finKind", "saldo");
            v.setTextViewText(R.id.wStatBig, finValue(p, fk));
            v.setTextViewText(R.id.wStatSub, finLabel(fk));

        } else if ("phrase".equals(type)) {
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, accent);
            String ph = d.optString("phrase", "").trim();
            if (ph.isEmpty()) ph = p.getString("phrase", "Bora, guerreiro! 🤠");
            v.setTextViewText(R.id.wPhrase, ph);

        } else if ("nota".equals(type)) {
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, night ? 0xFFE6E6EA : 0xFF33333A);
            String nt = p.getString("noteText", ""); if (nt.isEmpty()) nt = p.getString("noteTitle", "");
            v.setTextViewText(R.id.wPhrase, nt.isEmpty() ? "Fixe uma nota ou marque um recado no app." : nt);

        } else if ("meta".equals(type)) {
            v.setViewVisibility(R.id.metaBox, View.VISIBLE); v.setTextColor(R.id.metaSub, sub);
            JSONObject g = goalFor(p, d.optString("goalId", ""));
            if (g == null) { v.setTextViewText(R.id.metaSub, "Crie uma meta no app primeiro."); v.setProgressBar(R.id.metaBar, 100, 0, false); }
            else {
                int pct = g.optInt("pct", 0);
                v.setProgressBar(R.id.metaBar, 100, pct, false);
                String val = g.optBoolean("money", false)
                        ? ("R$ " + g.optInt("cur", 0) + " / R$ " + g.optInt("target", 0))
                        : (g.optInt("cur", 0) + "/" + g.optInt("target", 0) + " " + g.optString("scope", ""));
                v.setTextViewText(R.id.metaSub, val + " · " + pct + "%");
                v.setTextViewText(R.id.wTitle, (icon.isEmpty() ? "🎯 " : icon + " ") + g.optString("name", name));
            }

        } else if ("contador".equals(type)) {
            v.setViewVisibility(R.id.cntBox, View.VISIBLE);
            v.setTextColor(R.id.cntBig, accent); v.setTextColor(R.id.cntLabel, sub);
            int cnt = p.getInt("cnt_" + widgetId, 0);
            v.setTextViewText(R.id.cntBig, String.valueOf(cnt));
            v.setTextViewText(R.id.cntLabel, d.optString("counterLabel", "toque em + para somar"));
            Intent ci = new Intent(c, CustomWidget.class); ci.setAction(ACTION_CNT); ci.putExtra("wid", widgetId);
            v.setOnClickPendingIntent(R.id.cntPlus, PendingIntent.getBroadcast(c, ("cnt" + widgetId).hashCode(), ci, Widgets.piFlags()));

        } else if ("conquistas".equals(type)) {
            v.setViewVisibility(R.id.twoBox, View.VISIBLE);
            v.setTextColor(R.id.tbBig0, accent); v.setTextColor(R.id.tbBig1, accent);
            v.setTextColor(R.id.tbSub0, sub); v.setTextColor(R.id.tbSub1, sub);
            v.setTextViewText(R.id.tbBig0, "🏆 " + p.getInt("trophies", 0)); v.setTextViewText(R.id.tbSub0, "troféus");
            v.setTextViewText(R.id.tbBig1, "Nv " + p.getInt("level", 1)); v.setTextViewText(R.id.tbSub1, "nível");

        } else if ("agenda".equals(type)) {
            v.setViewVisibility(R.id.linesBox, View.VISIBLE);
            JSONArray ag = new JSONArray(); try { ag = new JSONArray(p.getString("agenda", "[]")); } catch (Exception ignored) {}
            int shown = Math.min(ag.length(), LROW.length);
            for (int i = 0; i < LROW.length; i++) {
                if (i < shown) {
                    JSONObject e = ag.optJSONObject(i); if (e == null) e = new JSONObject();
                    String emoji = e.optString("emoji", "📅"), nm = e.optString("name", ""), date = e.optString("date", "");
                    String dtxt = date.length() >= 10 ? (date.substring(8, 10) + "/" + date.substring(5, 7)) : "";
                    v.setViewVisibility(LROW[i], View.VISIBLE);
                    v.setTextViewText(LCHK[i], emoji); v.setTextColor(LCHK[i], accent);
                    v.setInt(LNAME[i], "setPaintFlags", Paint.ANTI_ALIAS_FLAG);
                    v.setTextViewText(LNAME[i], nm + (dtxt.isEmpty() ? "" : "  ·  " + dtxt));
                    v.setTextColor(LNAME[i], text);
                    v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, "hoje", 8800 + widgetId % 200 * 10 + i));
                } else v.setViewVisibility(LROW[i], View.GONE);
            }
            if (shown == 0) { v.setViewVisibility(LROW[0], View.VISIBLE); v.setTextViewText(LCHK[0], "•"); v.setTextColor(LCHK[0], sub); v.setTextViewText(LNAME[0], "Sem eventos próximos"); v.setTextColor(LNAME[0], sub); }

        } else if ("shortcuts".equals(type)) {
            v.setViewVisibility(R.id.scBox, View.VISIBLE);
            JSONArray sc = d.optJSONArray("shortcuts"); if (sc == null) sc = new JSONArray();
            for (int i = 0; i < SC.length; i++) {
                if (i < sc.length()) {
                    String key = sc.optString(i);
                    v.setViewVisibility(SC[i], View.VISIBLE);
                    v.setInt(SC[i], "setBackgroundResource", night ? R.drawable.chip_dark : R.drawable.chip_light);
                    v.setTextViewText(SCI[i], scEmoji(key)); v.setTextViewText(SCT[i], scLabel(key)); v.setTextColor(SCT[i], text);
                    v.setOnClickPendingIntent(SC[i], Widgets.openAction(c, key, 8700 + widgetId % 200 * 10 + i));
                } else v.setViewVisibility(SC[i], View.GONE);
            }

        } else {
            // checklist / list
            v.setViewVisibility(R.id.linesBox, View.VISIBLE);
            boolean isCheck = "checklist".equals(type);
            boolean group = d.optBoolean("group", false) && "routines".equals(source);
            String doneMode = d.optString("doneMode", "strike");
            boolean expanded = p.getBoolean("exp_" + widgetId, false);

            JSONArray items = itemsFor(p, d, source);
            ArrayList<JSONObject> pend = new ArrayList<>(), doneL = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) { JSONObject it = items.optJSONObject(i); if (it == null) continue; if (it.optBoolean("done", false)) doneL.add(it); else pend.add(it); }

            // itens principais: strike mostra todos; hide só pendentes
            ArrayList<JSONObject> main = new ArrayList<>();
            if (isCheck && "strike".equals(doneMode)) main.addAll(orderList(items));
            else main.addAll(pend);

            // monta as "células" (cabeçalho de período ou item)
            ArrayList<Object> cells = new ArrayList<>();
            if (group) {
                LinkedHashMap<String, ArrayList<JSONObject>> gr = new LinkedHashMap<>();
                gr.put("🌅 Manhã", new ArrayList<>()); gr.put("☀️ Tarde", new ArrayList<>()); gr.put("🌙 Noite", new ArrayList<>()); gr.put("🕓 Sem horário", new ArrayList<>());
                for (JSONObject it : main) { String L = periodLabel(it.optString("time", "")); ArrayList<JSONObject> bucket = gr.get(L); if (bucket != null) bucket.add(it); }
                for (String L : gr.keySet()) { ArrayList<JSONObject> bl = gr.get(L); if (bl != null && !bl.isEmpty()) { cells.add(L); cells.addAll(bl); } }
            } else {
                cells.addAll(main);
            }

            // seção Concluídas (só checklist, quando há concluídas e modo hide)
            boolean showConcl = isCheck && !doneL.isEmpty();
            if (showConcl) {
                cells.add("CONCL"); // marcador especial
                if (expanded && "hide".equals(doneMode)) cells.addAll(doneL);
            }

            int rowI = 0, doneCount = doneL.size(), total = items.length();
            for (int ci = 0; ci < cells.size() && rowI < LROW.length; ci++) {
                Object cell = cells.get(ci);
                int i = rowI;
                v.setViewVisibility(LROW[i], View.VISIBLE);
                if (cell instanceof String) {
                    String s = (String) cell;
                    v.setInt(LNAME[i], "setPaintFlags", Paint.ANTI_ALIAS_FLAG);
                    if ("CONCL".equals(s)) {
                        v.setTextViewText(LCHK[i], expanded ? "▾" : "▸"); v.setTextColor(LCHK[i], accent);
                        v.setTextViewText(LNAME[i], "✓ Concluídas (" + doneCount + ")"); v.setTextColor(LNAME[i], accent);
                        Intent ei = new Intent(c, CustomWidget.class); ei.setAction(ACTION_EXP); ei.putExtra("wid", widgetId);
                        v.setOnClickPendingIntent(LROW[i], PendingIntent.getBroadcast(c, ("exp" + widgetId).hashCode(), ei, Widgets.piFlags()));
                    } else {
                        v.setTextViewText(LCHK[i], ""); v.setTextViewText(LNAME[i], s); v.setTextColor(LNAME[i], accent);
                        v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, openScr, 8790 + widgetId % 200 * 10 + i));
                    }
                    rowI++;
                    continue;
                }
                JSONObject it = (JSONObject) cell;
                String emoji = it.optString("emoji", ""), nm = it.optString("name", "");
                boolean dn = it.optBoolean("done", false); String rid = it.optString("id", "");
                v.setTextViewText(LNAME[i], (emoji.isEmpty() ? "" : emoji + " ") + nm);
                v.setTextColor(LNAME[i], dn ? sub : text);
                v.setInt(LNAME[i], "setPaintFlags", dn ? (Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG) : Paint.ANTI_ALIAS_FLAG);
                if (isCheck) {
                    v.setTextViewText(LCHK[i], dn ? "☑" : "☐");
                    v.setTextColor(LCHK[i], dn ? accent : sub);
                    if ("routines".equals(source) && !rid.isEmpty()) {
                        Intent t = new Intent(c, CustomWidget.class); t.setAction(ACTION_TOGGLE); t.putExtra("rid", rid); t.putExtra("want", !dn);
                        v.setOnClickPendingIntent(LROW[i], PendingIntent.getBroadcast(c, ("cw" + widgetId + rid).hashCode(), t, Widgets.piFlags()));
                    } else {
                        v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, openScr, 8800 + widgetId % 200 * 10 + i));
                    }
                } else {
                    v.setTextViewText(LCHK[i], "•"); v.setTextColor(LCHK[i], accent);
                    v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, openScr, 8800 + widgetId % 200 * 10 + i));
                }
                rowI++;
            }
            for (int i = rowI; i < LROW.length; i++) v.setViewVisibility(LROW[i], View.GONE);

            if (isCheck && total > 0) { v.setViewVisibility(R.id.wCount, View.VISIBLE); v.setTextViewText(R.id.wCount, doneCount + "/" + total); }
            if (d.optBoolean("addBtn", false)) {
                v.setViewVisibility(R.id.wAdd, View.VISIBLE); v.setTextColor(R.id.wAdd, accent);
                String addAct = "reminders".equals(source) ? "reminder" : "wishes".equals(source) ? "wish" : "routines".equals(source) ? "routine" : "hoje";
                v.setOnClickPendingIntent(R.id.wAdd, Widgets.openAction(c, addAct, 8900 + widgetId % 300));
            }

            // faixa de atalhos no rodapé
            if (d.optBoolean("withShortcuts", false)) {
                JSONArray sc = d.optJSONArray("shortcuts"); if (sc == null) sc = new JSONArray();
                v.setViewVisibility(R.id.stripBox, View.VISIBLE);
                for (int i = 0; i < ST.length; i++) {
                    if (i < sc.length()) {
                        String key = sc.optString(i);
                        v.setViewVisibility(ST[i], View.VISIBLE);
                        v.setInt(ST[i], "setBackgroundResource", night ? R.drawable.chip_dark : R.drawable.chip_light);
                        v.setTextViewText(STI[i], scEmoji(key)); v.setTextViewText(STT[i], scLabel(key)); v.setTextColor(STT[i], text);
                        v.setOnClickPendingIntent(ST[i], Widgets.openAction(c, key, 8750 + widgetId % 200 * 10 + i));
                    } else v.setViewVisibility(ST[i], View.GONE);
                }
            }
        }
        m.updateAppWidget(widgetId, v);
    }

    private ArrayList<JSONObject> orderList(JSONArray items) {
        ArrayList<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) { JSONObject it = items.optJSONObject(i); if (it != null) out.add(it); }
        return out;
    }

    private String periodLabel(String time) {
        if (time == null || time.isEmpty()) return "🕓 Sem horário";
        try { int h = Integer.parseInt(time.split(":")[0]); if (h < 12) return "🌅 Manhã"; if (h < 18) return "☀️ Tarde"; return "🌙 Noite"; } catch (Exception e) { return "🕓 Sem horário"; }
    }

    private JSONObject goalFor(SharedPreferences p, String goalId) {
        try {
            JSONArray a = new JSONArray(p.getString("goals", "[]"));
            if (a.length() == 0) return null;
            if (goalId != null && !goalId.isEmpty()) for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && goalId.equals(o.optString("id"))) return o; }
            return a.optJSONObject(0);
        } catch (Exception e) { return null; }
    }

    private JSONArray itemsFor(SharedPreferences p, JSONObject d, String source) {
        try {
            if ("custom".equals(source)) {
                JSONArray lines = d.optJSONArray("lines"); if (lines == null) return new JSONArray();
                JSONArray out = new JSONArray();
                for (int i = 0; i < lines.length(); i++) { JSONObject l = lines.optJSONObject(i); if (l == null) continue; JSONObject o = new JSONObject(); o.put("name", l.optString("text", "")); o.put("emoji", l.optString("icon", "")); o.put("done", l.optBoolean("done", false)); out.put(o); }
                return out;
            }
            if ("reminders".equals(source)) return mapField(p.getString("reminders", "[]"), "text", "🔔");
            if ("wishes".equals(source)) return mapField(p.getString("wishes", "[]"), "name", "🛒");
            return new JSONArray(p.getString("routines", "[]"));
        } catch (Exception e) { return new JSONArray(); }
    }
    private JSONArray mapField(String raw, String field, String emoji) {
        JSONArray out = new JSONArray();
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o == null) continue; JSONObject n = new JSONObject(); n.put("name", o.optString(field, "")); n.put("emoji", emoji); out.put(n); } } catch (Exception ignored) {}
        return out;
    }
    private String statValue(SharedPreferences p, String kind) {
        if ("progress".equals(kind)) return p.getInt("pct", 0) + "%";
        if ("streak".equals(kind)) return "🔥 " + p.getInt("streak", 0);
        if ("coins".equals(kind)) return "🪙 " + p.getInt("coins", 0);
        if ("level".equals(kind)) return "Nv " + p.getInt("level", 1);
        if ("spend".equals(kind)) return "R$ " + p.getInt("spendToday", 0);
        return "";
    }
    private String statLabel(String kind) {
        if ("progress".equals(kind)) return "progresso de hoje";
        if ("streak".equals(kind)) return "sequência";
        if ("coins".equals(kind)) return "moedas do guerreiro";
        if ("level".equals(kind)) return "nível";
        if ("spend".equals(kind)) return "gasto de hoje";
        return "";
    }
    private String finValue(SharedPreferences p, String fk) {
        if ("spend".equals(fk)) return "R$ " + p.getInt("spendToday", 0);
        if ("receitas".equals(fk)) return "R$ " + p.getInt("finReceitas", 0);
        if ("despesas".equals(fk)) return "R$ " + p.getInt("finDespesas", 0);
        return "R$ " + p.getInt("finSaldo", 0);
    }
    private String finLabel(String fk) {
        if ("spend".equals(fk)) return "gasto de hoje";
        if ("receitas".equals(fk)) return "receitas do mês";
        if ("despesas".equals(fk)) return "despesas do mês";
        return "saldo do mês";
    }
    private String scEmoji(String k) {
        switch (k) { case "routine": return "✅"; case "wish": return "🛒"; case "expense": return "💸"; case "expense_card": return "💳"; case "reminder": return "🔔"; case "note": return "📝"; case "pontos": return "🏆"; default: return "🏠"; }
    }
    private String scLabel(String k) {
        switch (k) { case "routine": return "Rotina"; case "wish": return "Desejo"; case "expense": return "Despesa"; case "expense_card": return "Cartão"; case "reminder": return "Lembrete"; case "note": return "Nota"; case "pontos": return "Pontos"; default: return "Hoje"; }
    }
}
