package com.italo.minharotina;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;

/** Utilidades compartilhadas pelos widgets: cores/tema, preferências e intents. */
public class Widgets {
    static final String PREFS = "mr_widget";
    static final int ORANGE = 0xFFEF6C00;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, 0); }

    /** Cor de destaque (vinda do app, ou laranja padrão). */
    static int accent(Context c) {
        String hex = prefs(c).getString("accent", "#EF6C00");
        try { return Color.parseColor(hex); } catch (Exception e) { return ORANGE; }
    }

    /** true = usar tema escuro. Segue "system" (config do celular), "light" ou "dark". */
    static boolean night(Context c) {
        String m = prefs(c).getString("theme", "system");
        if ("light".equals(m)) return false;
        if ("dark".equals(m)) return true;
        int f = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return f == Configuration.UI_MODE_NIGHT_YES;
    }

    static int bgRes(Context c) { return night(c) ? R.drawable.bg_widget_dark : R.drawable.bg_widget_light; }
    static int chipRes(Context c) { return night(c) ? R.drawable.chip_dark : R.drawable.chip_light; }
    static int textColor(Context c) { return night(c) ? 0xFFF2F2F5 : 0xFF1A1A1E; }
    static int subColor(Context c) { return night(c) ? 0xFFAFAFB8 : 0xFF6A6A72; }

    static int piFlags() {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return f;
    }

    /** Abre o app executando uma ação (novo desejo, despesa, etc). */
    static PendingIntent openAction(Context c, String action, int req) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction("mr.widget." + action);
        i.putExtra("mr_action", action);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, req, i, piFlags());
    }

    /** Atualiza todos os widgets deste app. */
    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        Class<?>[] all = { RoutinesWidget.class, QuickAddWidget.class, ExpenseWidget.class, ProgressWidget.class, HeroWidget.class };
        for (Class<?> cls : all) {
            try {
                ComponentName cn = new ComponentName(c, cls);
                int[] ids = m.getAppWidgetIds(cn);
                if (ids != null && ids.length > 0) {
                    Intent i = new Intent(c, cls);
                    i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
                    i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                    c.sendBroadcast(i);
                }
            } catch (Exception ignored) {}
        }
    }
}
