package com.italo.minharotina;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class WidgetConfigActivity extends Activity {
    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        Bundle ex = getIntent().getExtras();
        if (ex != null) appWidgetId = ex.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

        float dp = getResources().getDisplayMetrics().density;
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this); ll.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * dp); ll.setPadding(pad, pad, pad, pad);
        ll.setBackgroundColor(dark ? 0xFF15151A : 0xFFFFFFFF);

        TextView h = new TextView(this); h.setText("Escolha um widget"); h.setTextSize(20);
        h.setTextColor(dark ? 0xFFFFFFFF : 0xFF1A1A1E); h.getPaint().setFakeBoldText(true); ll.addView(h);

        JSONArray arr = new JSONArray();
        try { arr = new JSONArray(getSharedPreferences(Widgets.PREFS, 0).getString("customWidgets", "[]")); } catch (Exception ignored) {}
        if (arr.length() == 0) {
            TextView t = new TextView(this); t.setText("\nNenhum modelo ainda.\nAbra o app › Widgets e crie um.");
            t.setTextColor(dark ? 0xFFBBBBBB : 0xFF555555); ll.addView(t);
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i); if (o == null) continue;
            final String id = o.optString("id");
            String name = o.optString("name", "Widget"), icon = o.optString("icon", "🧩"), type = o.optString("type", "");
            Button btn = new Button(this); btn.setAllCaps(false);
            btn.setText(icon + "  " + name + "   ·  " + typeLabel(type));
            btn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = (int) (10 * dp); btn.setLayoutParams(lp);
            btn.setOnClickListener(v -> pick(id));
            ll.addView(btn);
        }
        sv.addView(ll); setContentView(sv);
    }

    private String typeLabel(String t) {
        switch (t) { case "checklist": return "Checklist"; case "list": return "Lista"; case "shortcuts": return "Atalhos"; case "stat": return "Número"; case "phrase": return "Frase"; default: return t; }
    }

    private void pick(String designId) {
        getSharedPreferences(Widgets.PREFS, 0).edit().putString("cfg_" + appWidgetId, designId).apply();
        Intent up = new Intent(this, CustomWidget.class);
        up.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        up.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{ appWidgetId });
        sendBroadcast(up);
        Intent res = new Intent(); res.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, res); finish();
    }
}
