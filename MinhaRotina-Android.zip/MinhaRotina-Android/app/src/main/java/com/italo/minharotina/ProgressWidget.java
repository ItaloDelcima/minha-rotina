package com.italo.minharotina;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/** Widget "Progresso de hoje": % concluído, rotinas, sequência e moedas. */
public class ProgressWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        SharedPreferences p = Widgets.prefs(c);
        int accent = Widgets.accent(c), text = Widgets.textColor(c), sub = Widgets.subColor(c);
        int done = p.getInt("doneCount", 0), total = p.getInt("total", 0), pct = p.getInt("pct", 0);
        int streak = p.getInt("streak", 0), coins = p.getInt("coins", 0);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_progress);
            v.setInt(R.id.root, "setBackgroundResource", Widgets.bgRes(c));
            v.setTextColor(R.id.wTitle, sub);
            v.setTextColor(R.id.wPct, accent);
            v.setTextColor(R.id.wDone, text);
            v.setTextColor(R.id.wExtra, sub);
            v.setTextViewText(R.id.wPct, pct + "%");
            v.setTextViewText(R.id.wDone, done + "/" + total + " rotinas concluídas");
            v.setTextViewText(R.id.wExtra, "🔥 " + streak + "  ·  🪙 " + coins);
            v.setOnClickPendingIntent(R.id.root, Widgets.openAction(c, "pontos", 8301));
            m.updateAppWidget(id, v);
        }
    }
}
