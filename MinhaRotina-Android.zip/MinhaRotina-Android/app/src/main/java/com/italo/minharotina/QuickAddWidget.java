package com.italo.minharotina;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** Widget "Ações rápidas": atalhos para criar rotina, desejo, despesa, despesa no cartão, lembrete e nota. */
public class QuickAddWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_quickadd);
            int text = Widgets.textColor(c);
            v.setInt(R.id.root, "setBackgroundResource", Widgets.bgRes(c));
            v.setTextColor(R.id.wTitle, text);
            int[] chips = { R.id.chipRoutine, R.id.chipWish, R.id.chipExpense, R.id.chipCard, R.id.chipReminder, R.id.chipNote };
            int[] labels = { R.id.lblRoutine, R.id.lblWish, R.id.lblExpense, R.id.lblCard, R.id.lblReminder, R.id.lblNote };
            for (int cid : chips) v.setInt(cid, "setBackgroundResource", Widgets.chipRes(c));
            for (int lid : labels) v.setTextColor(lid, text);
            v.setOnClickPendingIntent(R.id.chipRoutine, Widgets.openAction(c, "routine", 8101));
            v.setOnClickPendingIntent(R.id.chipWish, Widgets.openAction(c, "wish", 8102));
            v.setOnClickPendingIntent(R.id.chipExpense, Widgets.openAction(c, "expense", 8103));
            v.setOnClickPendingIntent(R.id.chipCard, Widgets.openAction(c, "expense_card", 8104));
            v.setOnClickPendingIntent(R.id.chipReminder, Widgets.openAction(c, "reminder", 8105));
            v.setOnClickPendingIntent(R.id.chipNote, Widgets.openAction(c, "note", 8106));
            m.updateAppWidget(id, v);
        }
    }
}
