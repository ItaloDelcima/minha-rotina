package com.italo.minharotina;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/** Widget "Meu guerreiro": nível, chefão atual e vida do herói. */
public class HeroWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        SharedPreferences p = Widgets.prefs(c);
        int accent = Widgets.accent(c), text = Widgets.textColor(c), sub = Widgets.subColor(c);
        int level = p.getInt("level", 1);
        int bossNum = p.getInt("bossNum", 1);
        String bossName = p.getString("bossName", "");
        int hp = p.getInt("heroHp", 0), hpMax = p.getInt("heroMax", 0);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_hero);
            v.setInt(R.id.root, "setBackgroundResource", Widgets.bgRes(c));
            v.setTextColor(R.id.wTitle, sub);
            v.setTextColor(R.id.wLevel, accent);
            v.setTextColor(R.id.wBoss, text);
            v.setTextColor(R.id.wHp, sub);
            v.setTextViewText(R.id.wLevel, "Nível " + level);
            v.setTextViewText(R.id.wBoss, "Chefão " + bossNum + "/100" + (bossName.isEmpty() ? "" : " · " + bossName));
            v.setTextViewText(R.id.wHp, hpMax > 0 ? ("❤️ " + hp + "/" + hpMax) : "❤️ pronto para a batalha");
            v.setOnClickPendingIntent(R.id.root, Widgets.openAction(c, "guerreiro", 8401));
            m.updateAppWidget(id, v);
        }
    }
}
