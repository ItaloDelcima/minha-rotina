package com.italo.minharotina;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONObject;

import java.util.ArrayList;

/** Fornece as linhas roláveis do widget personalizado (todas as atividades, sem limite). */
public class CustomListService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext(), intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1));
    }

    static class Factory implements RemoteViewsFactory {
        private final Context c; private final int wid;
        private ArrayList<JSONObject> cells = new ArrayList<>();
        private int text, sub, accent;

        Factory(Context c, int wid) { this.c = c; this.wid = wid; }

        @Override public void onCreate() {}
        @Override public void onDestroy() { cells.clear(); }

        @Override public void onDataSetChanged() {
            JSONObject d = CustomWidget.designFor(c, wid);
            boolean night = CustomWidget.night(c, d);
            text = night ? 0xFFF2F2F5 : 0xFF1A1A1E; sub = night ? 0xFFAFAFB8 : 0xFF6A6A72;
            accent = CustomWidget.accentOf(c, d);
            cells = CustomWidget.buildCells(c, wid);
        }

        @Override public int getCount() { return cells.size(); }

        @Override public RemoteViews getViewAt(int pos) {
            if (pos < 0 || pos >= cells.size()) return null;
            JSONObject o = cells.get(pos);
            String k = o.optString("k", "i");
            RemoteViews v;
            if ("h".equals(k) || "c".equals(k)) {
                v = new RemoteViews(c.getPackageName(), R.layout.wrow_header);
                v.setTextViewText(R.id.wrHead, o.optString("text", ""));
                v.setTextColor(R.id.wrHead, accent);
                Intent f = new Intent();
                if ("c".equals(k)) f.putExtra("kind", "exp"); else f.putExtra("kind", "none");
                v.setOnClickFillInIntent(R.id.wrHead, f);
                return v;
            }
            v = new RemoteViews(c.getPackageName(), R.layout.wrow_item);
            boolean dn = o.optBoolean("done", false), chk = o.optBoolean("chk", false);
            v.setTextViewText(R.id.wrChk, o.optString("mark", "•"));
            v.setTextColor(R.id.wrChk, chk ? (dn ? accent : sub) : accent);
            v.setTextViewText(R.id.wrName, o.optString("text", ""));
            v.setTextColor(R.id.wrName, dn ? sub : text);
            v.setInt(R.id.wrName, "setPaintFlags", dn ? (Paint.STRIKE_THRU_TEXT_FLAG | Paint.ANTI_ALIAS_FLAG) : Paint.ANTI_ALIAS_FLAG);
            Intent f = new Intent();
            String act = o.optString("act", "open");
            f.putExtra("kind", act);
            if ("toggle".equals(act)) { f.putExtra("rid", o.optString("rid", "")); f.putExtra("want", o.optBoolean("want", true)); }
            else f.putExtra("scr", o.optString("scr", "hoje"));
            v.setOnClickFillInIntent(R.id.wrRoot, f);
            return v;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public long getItemId(int pos) { return pos; }
        @Override public boolean hasStableIds() { return false; }
    }
}
