package com.italo.minharotina;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Reagenda as notificações depois que o celular reinicia. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            ReminderScheduler.reschedule(c);
        }
    }
}
