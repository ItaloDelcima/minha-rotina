package com.italo.minharotina;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private FrameLayout root;
    private View lockView;
    private boolean locked = false;
    private boolean authenticating = false;
    static final String PREFS = "mr_prefs";
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 2011;
    private boolean pageLoaded = false;
    private String pendingWidgetAction = null;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        getWindow().setStatusBarColor(0xFFEF6C00);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView wv, String url) {
                pageLoaded = true;
                if (pendingWidgetAction != null) { runWidgetAction(pendingWidgetAction); pendingWidgetAction = null; }
                applyWidgetToggles();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }
                try { startActivityForResult(Intent.createChooser(intent, "Escolher arquivo"), FILE_CHOOSER_REQ); }
                catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir os arquivos", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setDownloadListener((url, ua, cd, mime, len) ->
                Toast.makeText(this, "Use \"Salvar backup\" para escolher onde guardar.", Toast.LENGTH_LONG).show());
        webView.addJavascriptInterface(new Bridge(), "Android");

        root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        lockView = buildLockView();
        lockView.setVisibility(View.GONE);
        root.addView(lockView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        if (st != null) webView.restoreState(st);
        else webView.loadUrl("file:///android_asset/index.html");

        handleWidgetIntent(getIntent());
        maybeAskNotif();

        if (lockEnabled()) { locked = true; lockView.setVisibility(View.VISIBLE); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQ) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) results = new Uri[]{ Uri.parse(dataString) };
                else if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    private boolean lockEnabled() { return getSharedPreferences(PREFS, 0).getBoolean("lock", false); }

    private View buildLockView() {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setGravity(Gravity.CENTER);
        ll.setBackgroundColor(0xFFEF6C00);
        ll.setClickable(true);
        TextView t = new TextView(this);
        t.setText("🔥 Minha Rotina");
        t.setTextColor(Color.WHITE); t.setTextSize(24); t.setGravity(Gravity.CENTER);
        TextView t2 = new TextView(this);
        t2.setText("Toque para desbloquear");
        t2.setTextColor(0xFFFFE0C0); t2.setTextSize(15); t2.setPadding(0, 20, 0, 0); t2.setGravity(Gravity.CENTER);
        ll.addView(t); ll.addView(t2);
        ll.setOnClickListener(v -> authenticate());
        return ll;
    }

    private void authenticate() {
        if (authenticating) return;
        int auth = (Build.VERSION.SDK_INT >= 30)
                ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        BiometricManager bm = BiometricManager.from(this);
        if (bm.canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) { unlock(); return; }
        authenticating = true;
        Executor ex = ContextCompat.getMainExecutor(this);
        BiometricPrompt bp = new BiometricPrompt(this, ex, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { unlock(); }
            @Override public void onAuthenticationError(int code, CharSequence msg) { authenticating = false; }
        });
        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Minha Rotina").setSubtitle("Desbloqueie para continuar").setAllowedAuthenticators(auth);
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancelar");
        try { bp.authenticate(b.build()); } catch (Exception e) { authenticating = false; unlock(); }
    }

    private void unlock() { locked = false; authenticating = false; lockView.setVisibility(View.GONE); }

    private void bioUnlockPrompt() {
        int auth = (Build.VERSION.SDK_INT >= 30)
                ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        BiometricManager bm = BiometricManager.from(this);
        if (bm.canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) { bioResult(false); return; }
        Executor ex = ContextCompat.getMainExecutor(this);
        BiometricPrompt bp = new BiometricPrompt(this, ex, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { bioResult(true); }
            @Override public void onAuthenticationError(int code, CharSequence msg) { bioResult(false); }
        });
        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Minha Rotina").setSubtitle("Desbloqueie").setAllowedAuthenticators(auth);
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancelar");
        try { bp.authenticate(b.build()); } catch (Exception e) { bioResult(false); }
    }

    private void bioResult(boolean ok) {
        if (webView != null) webView.evaluateJavascript("window.__bioResult && window.__bioResult(" + ok + ")", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lockEnabled() && locked) { lockView.setVisibility(View.VISIBLE); authenticate(); }
        if (pageLoaded) applyWidgetToggles();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (lockEnabled() && !isFinishing()) locked = true;
    }

    private void maybeAskNotif() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            try { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101); } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); webView.saveState(o); }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent); }

    private void handleWidgetIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getStringExtra("mr_action");
        if (action == null) return;
        if (pageLoaded) runWidgetAction(action); else pendingWidgetAction = action;
    }
    private void runWidgetAction(String action) {
        if (webView == null || action == null) return;
        final String a = action.replace("'", "");
        runOnUiThread(() -> webView.evaluateJavascript("window.__widgetAction && window.__widgetAction('" + a + "')", null));
    }
    private void applyWidgetToggles() {
        if (webView == null) return;
        runOnUiThread(() -> webView.evaluateJavascript("window.__pullWidgetToggles && window.__pullWidgetToggles()", null));
    }

    class Bridge {
        @JavascriptInterface public boolean isNativeApp() { return true; }

        @JavascriptInterface public void setLock(boolean on) {
            getSharedPreferences(PREFS, 0).edit().putBoolean("lock", on).apply();
        }

        @JavascriptInterface public boolean biometricAvailable() {
            int auth = (Build.VERSION.SDK_INT >= 30)
                    ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    : BiometricManager.Authenticators.BIOMETRIC_WEAK;
            return BiometricManager.from(MainActivity.this).canAuthenticate(auth) == BiometricManager.BIOMETRIC_SUCCESS;
        }

        @JavascriptInterface public void setReminders(String json) {
            ReminderScheduler.schedule(getApplicationContext(), json);
        }

        @JavascriptInterface public void syncWidget(String json) {
            try {
                org.json.JSONObject o = new org.json.JSONObject(json);
                android.content.SharedPreferences.Editor e = getSharedPreferences(Widgets.PREFS, 0).edit();
                if (o.has("routines")) e.putString("routines", o.getJSONArray("routines").toString());
                if (o.has("reminders")) e.putString("reminders", o.getJSONArray("reminders").toString());
                if (o.has("wishes")) e.putString("wishes", o.getJSONArray("wishes").toString());
                if (o.has("customWidgets")) e.putString("customWidgets", o.getJSONArray("customWidgets").toString());
                e.putString("phrase", o.optString("phrase", ""));
                e.putInt("doneCount", o.optInt("doneCount", 0));
                e.putInt("total", o.optInt("total", 0));
                e.putInt("pct", o.optInt("pct", 0));
                e.putInt("streak", o.optInt("streak", 0));
                e.putInt("coins", o.optInt("coins", 0));
                e.putInt("level", o.optInt("level", 1));
                e.putInt("bossNum", o.optInt("bossNum", 1));
                e.putString("bossName", o.optString("bossName", ""));
                e.putInt("heroHp", o.optInt("heroHp", 0));
                e.putInt("heroMax", o.optInt("heroMax", 0));
                e.putInt("spendToday", (int) Math.round(o.optDouble("spendToday", 0)));
                e.putInt("finSaldo", (int) Math.round(o.optDouble("finSaldo", 0)));
                e.putInt("finReceitas", (int) Math.round(o.optDouble("finReceitas", 0)));
                e.putInt("finDespesas", (int) Math.round(o.optDouble("finDespesas", 0)));
                e.putInt("trophies", o.optInt("trophies", 0));
                e.putString("noteTitle", o.optString("noteTitle", ""));
                e.putString("noteText", o.optString("noteText", ""));
                if (o.has("agenda")) e.putString("agenda", o.getJSONArray("agenda").toString());
                if (o.has("goals")) e.putString("goals", o.getJSONArray("goals").toString());
                if (o.has("accent")) e.putString("accent", o.optString("accent", "#EF6C00"));
                if (o.has("theme")) e.putString("theme", o.optString("theme", "system"));
                e.apply();
                Widgets.updateAll(getApplicationContext());
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public String pullWidgetToggles() {
            android.content.SharedPreferences p = getSharedPreferences(Widgets.PREFS, 0);
            String pend = p.getString("pending", "[]");
            p.edit().putString("pending", "[]").apply();
            return pend;
        }

        @JavascriptInterface public boolean hasNotifPermission() {
            return Build.VERSION.SDK_INT < 33
                    || ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public void requestNotifPermission() { runOnUiThread(MainActivity.this::maybeAskNotif); }

        @JavascriptInterface public void authenticate() { runOnUiThread(() -> bioUnlockPrompt()); }

        @JavascriptInterface public String pinWidget(String kind, String designId) {
            try {
                if (Build.VERSION.SDK_INT < 26) return "old";
                android.appwidget.AppWidgetManager am = android.appwidget.AppWidgetManager.getInstance(MainActivity.this);
                if (!am.isRequestPinAppWidgetSupported()) return "unsupported";
                Class<?> cls;
                switch (kind == null ? "" : kind) {
                    case "routines": cls = RoutinesWidget.class; break;
                    case "quickadd": cls = QuickAddWidget.class; break;
                    case "expense": cls = ExpenseWidget.class; break;
                    case "progress": cls = ProgressWidget.class; break;
                    case "hero": cls = HeroWidget.class; break;
                    default: cls = CustomWidget.class;
                }
                android.content.ComponentName cn = new android.content.ComponentName(MainActivity.this, cls);
                android.app.PendingIntent cb = null;
                if (cls == CustomWidget.class) {
                    String did = designId == null ? "" : designId;
                    getSharedPreferences(Widgets.PREFS, 0).edit().putString("pendingPin", did).putLong("pendingPinAt", System.currentTimeMillis()).apply();
                    Intent ci = new Intent(MainActivity.this, CustomWidget.class);
                    ci.setAction(CustomWidget.ACTION_PINNED); ci.putExtra("did", did);
                    int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? android.app.PendingIntent.FLAG_MUTABLE : 0);
                    cb = android.app.PendingIntent.getBroadcast(MainActivity.this, ("pin" + did).hashCode(), ci, fl);
                }
                return am.requestPinAppWidget(cn, null, cb) ? "ok" : "fail";
            } catch (Exception e) { return "fail"; }
        }

        @JavascriptInterface public void saveBackup(String name, String content) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                        cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        cv.put(MediaStore.Downloads.IS_PENDING, 1);
                        ContentResolver cr = getContentResolver();
                        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        if (uri != null) {
                            OutputStream os = cr.openOutputStream(uri);
                            os.write(content.getBytes("UTF-8")); os.close();
                            cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0); cr.update(uri, cv, null, null);
                            Toast.makeText(MainActivity.this, "Backup salvo em Downloads/" + name, Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                    File dir = getExternalFilesDir(null);
                    File f = new File(dir, name);
                    FileOutputStream fo = new FileOutputStream(f);
                    fo.write(content.getBytes("UTF-8")); fo.close();
                    Toast.makeText(MainActivity.this, "Backup salvo em " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Erro ao salvar backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
