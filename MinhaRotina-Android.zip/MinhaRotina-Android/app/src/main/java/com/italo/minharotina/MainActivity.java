package com.italo.minharotina;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private FrameLayout root;
    private View lockView;
    private boolean locked = false;
    private boolean authenticating = false;
    static final String PREFS = "mr_prefs";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        getWindow().setStatusBarColor(0xFFEF6C00);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setDownloadListener((url, ua, cd, mime, len) ->
                Toast.makeText(this, "Use \"Salvar backup\" para escolher onde guardar.", Toast.LENGTH_LONG).show());
        webView.addJavascriptInterface(new Bridge(), "Android");

        root = new FrameLayout(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        lockView = buildLockView();
        lockView.setVisibility(View.GONE);
        root.addView(lockView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        if (st != null) webView.restoreState(st);
        else webView.loadUrl("file:///android_asset/index.html");

        maybeAskNotif();

        if (lockEnabled()) {                 // cobre o conteúdo já no início
            locked = true;
            lockView.setVisibility(View.VISIBLE);
        }
    }

    private boolean lockEnabled() {
        return getSharedPreferences(PREFS, 0).getBoolean("lock", false);
    }

    private View buildLockView() {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setGravity(Gravity.CENTER);
        ll.setBackgroundColor(0xFFEF6C00);
        ll.setClickable(true);
        TextView t = new TextView(this);
        t.setText("🔥 Minha Rotina");
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setGravity(Gravity.CENTER);
        TextView t2 = new TextView(this);
        t2.setText("Toque para desbloquear");
        t2.setTextColor(0xFFFFE0C0);
        t2.setTextSize(15);
        t2.setPadding(0, 20, 0, 0);
        t2.setGravity(Gravity.CENTER);
        ll.addView(t);
        ll.addView(t2);
        ll.setOnClickListener(v -> authenticate());
        return ll;
    }

    private void authenticate() {
        if (authenticating) return;
        int auth = (Build.VERSION.SDK_INT >= 30)
                ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        BiometricManager bm = BiometricManager.from(this);
        if (bm.canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            unlock();   // sem digital/PIN configurado: não trava o usuário
            return;
        }
        authenticating = true;
        Executor ex = ContextCompat.getMainExecutor(this);
        BiometricPrompt bp = new BiometricPrompt(this, ex, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                unlock();
            }
            @Override
            public void onAuthenticationError(int code, CharSequence msg) {
                authenticating = false;   // usuário cancelou: pode tocar para tentar de novo
            }
        });
        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Minha Rotina")
                .setSubtitle("Desbloqueie para continuar")
                .setAllowedAuthenticators(auth);
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancelar");
        try {
            bp.authenticate(b.build());
        } catch (Exception e) {
            authenticating = false;
            unlock();
        }
    }

    private void unlock() {
        locked = false;
        authenticating = false;
        lockView.setVisibility(View.GONE);
    }

    /** Desbloqueio por digital/PIN sob demanda (pastas das Anotações). Resultado volta em window.__bioResult(bool). */
    private void bioUnlockPrompt() {
        int auth = (Build.VERSION.SDK_INT >= 30)
                ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                : BiometricManager.Authenticators.BIOMETRIC_WEAK;
        BiometricManager bm = BiometricManager.from(this);
        if (bm.canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            bioResult(false);
            return;
        }
        Executor ex = ContextCompat.getMainExecutor(this);
        BiometricPrompt bp = new BiometricPrompt(this, ex, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) { bioResult(true); }
            @Override
            public void onAuthenticationError(int code, CharSequence msg) { bioResult(false); }
        });
        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Anotações")
                .setSubtitle("Desbloqueie a pasta")
                .setAllowedAuthenticators(auth);
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancelar");
        try {
            bp.authenticate(b.build());
        } catch (Exception e) {
            bioResult(false);
        }
    }

    private void bioResult(boolean ok) {
        if (webView != null) webView.evaluateJavascript("window.__bioResult && window.__bioResult(" + ok + ")", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lockEnabled() && locked) {
            lockView.setVisibility(View.VISIBLE);
            authenticate();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (lockEnabled() && !isFinishing()) {
            locked = true;   // re-bloqueia ao voltar do segundo plano
        }
    }

    private void maybeAskNotif() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            try {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        webView.saveState(o);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    /** Ponte JavaScript <-> Android (window.Android no app web). */
    class Bridge {
        @JavascriptInterface
        public boolean isNativeApp() { return true; }

        @JavascriptInterface
        public void setLock(boolean on) {
            getSharedPreferences(PREFS, 0).edit().putBoolean("lock", on).apply();
        }

        @JavascriptInterface
        public boolean biometricAvailable() {
            int auth = (Build.VERSION.SDK_INT >= 30)
                    ? (BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    : BiometricManager.Authenticators.BIOMETRIC_WEAK;
            return BiometricManager.from(MainActivity.this).canAuthenticate(auth) == BiometricManager.BIOMETRIC_SUCCESS;
        }

        @JavascriptInterface
        public void setReminders(String json) {
            ReminderScheduler.schedule(getApplicationContext(), json);
        }

        @JavascriptInterface
        public boolean hasNotifPermission() {
            return Build.VERSION.SDK_INT < 33
                    || ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(MainActivity.this::maybeAskNotif);
        }

        @JavascriptInterface
        public void authenticate() {
            runOnUiThread(() -> bioUnlockPrompt());
        }

        @JavascriptInterface
        public void saveBackup(String name, String content) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                        cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        cv.put(MediaStore.Downloads.IS_PENDING, 1);
                        ContentResolver cr = getContentResolver();
                        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        if (uri != null) {
                            OutputStream os = cr.openOutputStream(uri);
                            os.write(content.getBytes("UTF-8"));
                            os.close();
                            cv.clear();
                            cv.put(MediaStore.Downloads.IS_PENDING, 0);
                            cr.update(uri, cv, null, null);
                            Toast.makeText(MainActivity.this, "Backup salvo em Downloads/" + name, Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                    File dir = getExternalFilesDir(null);
                    File f = new File(dir, name);
                    FileOutputStream fo = new FileOutputStream(f);
                    fo.write(content.getBytes("UTF-8"));
                    fo.close();
                    Toast.makeText(MainActivity.this, "Backup salvo em " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Erro ao salvar backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
