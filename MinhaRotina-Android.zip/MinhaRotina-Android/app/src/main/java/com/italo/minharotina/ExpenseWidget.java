package com.italo.minharotina;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** Widget dedicado para lançar despesa, com opção de registrar no cartão de crédito. */
public class ExpenseWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_expense);
            int text = Widgets.textColor(c), sub = Widgets.subColor(c);
            v.setInt(R.id.root, "setBackgroundResource", Widgets.bgRes(c));
            v.setTextColor(R.id.wTitle, text);
            v.setTextColor(R.id.wSub, sub);
            v.setInt(R.id.chipExpense, "setBackgroundResource", Widgets.chipRes(c));
            v.setInt(R.id.chipCard, "setBackgroundResource", Widgets.chipRes(c));
            v.setTextColor(R.id.lblExpense, text);
            v.setTextColor(R.id.lblCard, text);
            v.setOnClickPendingIntent(R.id.chipExpense, Widgets.openAction(c, "expense", 8201));
            v.setOnClickPendingIntent(R.id.chipCard, Widgets.openAction(c, "expense_card", 8202));
            m.updateAppWidget(id, v);
        }
    }
}
