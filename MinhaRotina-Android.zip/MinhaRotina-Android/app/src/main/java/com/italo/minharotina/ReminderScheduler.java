package com.italo.minharotina;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Agenda notificações diárias (repetição inexata, sem exigir permissão de alarme exato). */
public class ReminderScheduler {
    static final String PREFS = "mr_prefs";
    static final String KEY = "reminders_json";
    static final int MAX = 200;

    public static void save(Context c, String json) {
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, json).apply();
    }

    public static String load(Context c) {
        return c.getSharedPreferences(PREFS, 0).getString(KEY, "[]");
    }

    public static void reschedule(Context c) {
        schedule(c, load(c));
    }

    public static void schedule(Context c, String json) {
        save(c, json);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        // limpa agendamentos antigos
        for (int i = 0; i < MAX; i++) {
            am.cancel(make(c, i, null, null));
        }
        try {
            JSONArray arr = new JSONArray(json);
            int n = Math.min(arr.length(), MAX);
            for (int i = 0; i < n; i++) {
                JSONObject o = arr.getJSONObject(i);
                String type = o.optString("type", "daily");
                String title = o.optString("title", "Minha Rotina");
                String body = o.optString("body", "");
                if ("once".equals(type)) {
                    // lembrete com data/hora específica: aviso único
                    long at = o.optLong("at", 0L);
                    if (at > System.currentTimeMillis()) {
                        am.set(AlarmManager.RTC_WAKEUP, at, make(c, i, title, body));
                    }
                } else {
                    // rotina diária: repete todo dia no horário
                    int hour = o.optInt("hour", 8);
                    int min = o.optInt("min", 0);
                    Calendar cal = Calendar.getInstance();
                    cal.set(Calendar.HOUR_OF_DAY, hour);
                    cal.set(Calendar.MINUTE, min);
                    cal.set(Calendar.SECOND, 0);
                    cal.set(Calendar.MILLISECOND, 0);
                    if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                        cal.add(Calendar.DAY_OF_YEAR, 1);
                    }
                    am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
                            AlarmManager.INTERVAL_DAY, make(c, i, title, body));
                }
            }
        } catch (Exception e) { /* json inválido: ignora */ }
    }

    static PendingIntent make(Context c, int code, String title, String body) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction("mr.reminder." + code);
        if (title != null) i.putExtra("title", title);
        if (body != null) i.putExtra("body", body);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, code, i, flags);
    }
}
