package com.italo.minharotina;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Lê SOMENTE notificações de apps de banco/carteira conhecidos e guarda o texto bruto
 * (título + texto) para o app sugerir o lançamento. Nada é enviado para fora do celular.
 */
public class BankNotifListener extends NotificationListenerService {
    static final String[] BANKS = {
        "com.nu.production", "br.com.intermedium", "com.itau", "com.itau.iti", "br.com.bradesco", "br.com.bb.android",
        "br.com.gabba.Caixa", "br.gov.caixa.tem", "com.santander.app", "com.c6bank.app", "com.picpay", "com.mercadopago.wallet",
        "br.com.original.bank", "com.neon", "br.com.bradesco.next", "com.btg.pactual.banking", "br.com.xp.carteira",
        "com.sicredi.app", "br.com.sicoob.sicoobnet", "com.bancopan.app", "br.com.banrisul", "com.will.bank",
        "com.google.android.apps.walletnfcrel", "com.samsung.android.spay", "br.com.digio", "com.pagseguro.pagbank", "br.com.uol.ps.myaccount"
    };

    static boolean isBank(String pkg) { if (pkg == null) return false; for (String b : BANKS) if (b.equals(pkg)) return true; return false; }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !isBank(sbn.getPackageName())) return;
            Notification n = sbn.getNotification(); if (n == null) return;
            Bundle ex = n.extras; if (ex == null) return;
            CharSequence t = ex.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence tx = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (tx == null) tx = ex.getCharSequence(Notification.EXTRA_TEXT);
            String title = t == null ? "" : t.toString(), text = tx == null ? "" : tx.toString();
            String all = title + " " + text;
            if (!all.contains("R$")) return; // só o que tem valor em reais
            SharedPreferences p = Widgets.prefs(this);
            JSONArray arr = new JSONArray(p.getString("bankPending", "[]"));
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length(); i++) { // evita duplicado (mesmo texto em 3 min)
                JSONObject o = arr.optJSONObject(i);
                if (o != null && all.equals(o.optString("title") + " " + o.optString("text")) && now - o.optLong("time", 0L) < 180000L) return;
            }
            JSONObject o = new JSONObject();
            o.put("pkg", sbn.getPackageName()); o.put("title", title); o.put("text", text); o.put("time", now);
            JSONArray next = new JSONArray(); next.put(o);
            for (int i = 0; i < arr.length() && next.length() < 60; i++) next.put(arr.optJSONObject(i));
            p.edit().putString("bankPending", next.toString()).apply();
        } catch (Exception ignored) {}
    }
}
