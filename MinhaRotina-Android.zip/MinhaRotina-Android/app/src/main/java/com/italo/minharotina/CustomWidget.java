package com.italo.minharotina;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class CustomWidget extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.italo.minharotina.CW_TOGGLE";
    static final String ACTION_CNT = "com.italo.minharotina.CW_CNT";
    static final String ACTION_EXP = "com.italo.minharotina.CW_EXP";
    static final String ACTION_PINNED = "com.italo.minharotina.CW_PINNED";
    static final String ACTION_ROW = "com.italo.minharotina.CW_ROW";
    private static final int[] SC  = { R.id.sc0, R.id.sc1, R.id.sc2, R.id.sc3, R.id.sc4, R.id.sc5 };
    private static final int[] SCI = { R.id.sc0i, R.id.sc1i, R.id.sc2i, R.id.sc3i, R.id.sc4i, R.id.sc5i };
    private static final int[] SCT = { R.id.sc0t, R.id.sc1t, R.id.sc2t, R.id.sc3t, R.id.sc4t, R.id.sc5t };
    private static final int[] ST  = { R.id.st0, R.id.st1, R.id.st2, R.id.st3 };
    private static final int[] STI = { R.id.st0i, R.id.st1i, R.id.st2i, R.id.st3i };
    private static final int[] STT = { R.id.st0t, R.id.st1t, R.id.st2t, R.id.st3t };

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        SharedPreferences p = Widgets.prefs(c);
        String pend = p.getString("pendingPin", "");
        if (System.currentTimeMillis() - p.getLong("pendingPinAt", 0L) > 5 * 60 * 1000L) pend = ""; // pedido antigo expira
        for (int id : ids) {
            // só um widget NOVO (nunca desenhado) herda o modelo pedido pelo botão "Pôr na tela"
            if (!pend.isEmpty() && !p.contains("cfg_" + id) && !p.getBoolean("seen_" + id, false)) {
                p.edit().putString("cfg_" + id, pend).remove("pendingPin").apply(); pend = "";
            }
            render(c, m, id);
        }
    }

    @Override public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = Widgets.prefs(c).edit();
        for (int id : ids) { e.remove("cfg_" + id); e.remove("cnt_" + id); e.remove("exp_" + id); e.remove("seen_" + id); }
        e.apply();
    }

    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        String a = intent.getAction();
        if (ACTION_TOGGLE.equals(a)) {
            String rid = intent.getStringExtra("rid");
            boolean want = intent.getBooleanExtra("want", true);
            if (rid != null) { toggleRoutine(c, rid, want); Widgets.updateAll(c); }
        } else if (ACTION_CNT.equals(a)) {
            int wid = intent.getIntExtra("wid", -1);
            if (wid >= 0) {
                SharedPreferences p = Widgets.prefs(c);
                p.edit().putInt("cnt_" + wid, p.getInt("cnt_" + wid, 0) + 1).apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            }
        } else if (ACTION_PINNED.equals(a)) {
            int wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
            String did = intent.getStringExtra("did");
            if (wid >= 0 && did != null && !did.isEmpty()) {
                Widgets.prefs(c).edit().putString("cfg_" + wid, did).remove("pendingPin").apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            }
        } else if (ACTION_ROW.equals(a)) {
            String kind = intent.getStringExtra("kind"); int wid = intent.getIntExtra("wid", -1);
            if ("toggle".equals(kind)) {
                String rid = intent.getStringExtra("rid");
                if (rid != null) { toggleRoutine(c, rid, intent.getBooleanExtra("want", true)); Widgets.updateAll(c); }
            } else if ("exp".equals(kind) && wid >= 0) {
                SharedPreferences p = Widgets.prefs(c);
                p.edit().putBoolean("exp_" + wid, !p.getBoolean("exp_" + wid, false)).apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            } else if ("open".equals(kind)) {
                try {
                    Intent o = new Intent(c, MainActivity.class);
                    String scr = intent.getStringExtra("scr"); if (scr == null) scr = "hoje";
                    o.setAction("mr.widget." + scr); o.putExtra("mr_action", scr);
                    o.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    c.startActivity(o);
                } catch (Exception ignored) {}
            }
        } else if (ACTION_EXP.equals(a)) {
            int wid = intent.getIntExtra("wid", -1);
            if (wid >= 0) {
                SharedPreferences p = Widgets.prefs(c);
                p.edit().putBoolean("exp_" + wid, !p.getBoolean("exp_" + wid, false)).apply();
                render(c, AppWidgetManager.getInstance(c), wid);
            }
        }
    }

    private void toggleRoutine(Context c, String rid, boolean want) {
        SharedPreferences p = Widgets.prefs(c);
        try {
            JSONArray arr = new JSONArray(p.getString("routines", "[]"));
            for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && rid.equals(o.optString("id"))) { o.put("done", want); break; } }
            JSONArray pend = new JSONArray(p.getString("pending", "[]")); JSONArray next = new JSONArray();
            for (int i = 0; i < pend.length(); i++) { JSONObject o = pend.optJSONObject(i); if (o != null && !rid.equals(o.optString("id"))) next.put(o); }
            JSONObject nw = new JSONObject(); nw.put("id", rid); nw.put("done", want); next.put(nw);
            p.edit().putString("routines", arr.toString()).putString("pending", next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static JSONObject designFor(Context c, int widgetId) {
        SharedPreferences p = Widgets.prefs(c);
        String did = p.getString("cfg_" + widgetId, "");
        try {
            JSONArray arr = new JSONArray(p.getString("customWidgets", "[]"));
            if (!did.isEmpty()) for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && did.equals(o.optString("id"))) return o; }
            if (arr.length() > 0) return arr.optJSONObject(0);
        } catch (Exception ignored) {}
        return null;
    }

    static boolean night(Context c, JSONObject d) {
        String m = d != null ? d.optString("theme", "system") : "system";
        if ("light".equals(m)) return false;
        if ("dark".equals(m)) return true;
        int f = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return f == Configuration.UI_MODE_NIGHT_YES;
    }
    static int accentOf(Context c, JSONObject d) {
        if (d != null) { String col = d.optString("color", "accent"); if (!"accent".equals(col)) { try { return Color.parseColor(col); } catch (Exception e) {} } }
        return Widgets.accent(c);
    }

    private void render(Context c, AppWidgetManager m, int widgetId) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_custom);
        JSONObject d = designFor(c, widgetId);
        boolean night = night(c, d);
        int text = night ? 0xFFF2F2F5 : 0xFF1A1A1E, sub = night ? 0xFFAFAFB8 : 0xFF6A6A72, accent = accentOf(c, d);
        v.setInt(R.id.root, "setBackgroundResource", night ? R.drawable.bg_widget_dark : R.drawable.bg_widget_light);
        v.setTextColor(R.id.wTitle, text); v.setTextColor(R.id.wCount, accent);
        // esconde todos os blocos
        v.setViewVisibility(R.id.statBox, View.GONE); v.setViewVisibility(R.id.wPhrase, View.GONE);
        v.setViewVisibility(R.id.linesBox, View.GONE); v.setViewVisibility(R.id.scBox, View.GONE);
        v.setViewVisibility(R.id.metaBox, View.GONE); v.setViewVisibility(R.id.cntBox, View.GONE);
        v.setViewVisibility(R.id.twoBox, View.GONE); v.setViewVisibility(R.id.stripBox, View.GONE);
        v.setViewVisibility(R.id.wCount, View.GONE); v.setViewVisibility(R.id.wAdd, View.GONE);

        if (d == null) {
            v.setTextViewText(R.id.wTitle, "Widget Trem Bão");
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, sub);
            v.setTextViewText(R.id.wPhrase, "Abra o app › Widgets para criar um modelo.");
            v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, "widgets", 8600 + (widgetId % 300)));
            m.updateAppWidget(widgetId, v); return;
        }

        {   // fixa este widget no seu próprio modelo (evita que dois widgets mostrem o mesmo)
            SharedPreferences pp = Widgets.prefs(c); SharedPreferences.Editor ed = pp.edit(); ed.putBoolean("seen_" + widgetId, true);
            if (!pp.contains("cfg_" + widgetId) && !d.optString("id", "").isEmpty()) ed.putString("cfg_" + widgetId, d.optString("id", ""));
            ed.apply();
        }
        String type = d.optString("type", "list"), name = d.optString("name", "Widget"), icon = d.optString("icon", ""), source = d.optString("source", "routines");
        v.setTextViewText(R.id.wTitle, (icon.isEmpty() ? "" : icon + " ") + name);
        String openScr = "stat".equals(type) || "conquistas".equals(type) ? "pontos"
                : "financas".equals(type) ? "fin"
                : "agenda".equals(type) ? "hoje"
                : "meta".equals(type) ? "metas"
                : "nota".equals(type) ? "notas"
                : "reminders".equals(source) ? "lembretes" : "wishes".equals(source) ? "desejos" : "hoje";
        v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, openScr, 8600 + (widgetId % 300)));

        SharedPreferences p = Widgets.prefs(c);
        boolean listWidget = false;

        if ("stat".equals(type)) {
            v.setViewVisibility(R.id.statBox, View.VISIBLE);
            v.setTextColor(R.id.wStatBig, accent); v.setTextColor(R.id.wStatSub, sub);
            String kind = d.optString("statKind", "progress");
            v.setTextViewText(R.id.wStatBig, statValue(p, kind));
            v.setTextViewText(R.id.wStatSub, statLabel(kind));

        } else if ("financas".equals(type)) {
            v.setViewVisibility(R.id.statBox, View.VISIBLE);
            v.setTextColor(R.id.wStatBig, accent); v.setTextColor(R.id.wStatSub, sub);
            String fk = d.optString("finKind", "saldo");
            v.setTextViewText(R.id.wStatBig, finValue(p, fk));
            v.setTextViewText(R.id.wStatSub, finLabel(fk));

        } else if ("phrase".equals(type)) {
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, accent);
            String ph = d.optString("phrase", "").trim();
            if (ph.isEmpty()) ph = p.getString("phrase", "Bora, guerreiro! 🤠");
            v.setTextViewText(R.id.wPhrase, ph);

        } else if ("nota".equals(type)) {
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, night ? 0xFFE6E6EA : 0xFF33333A);
            String nt = p.getString("noteText", ""); if (nt.isEmpty()) nt = p.getString("noteTitle", "");
            v.setTextViewText(R.id.wPhrase, nt.isEmpty() ? "Fixe uma nota ou marque um recado no app." : nt);

        } else if ("meta".equals(type)) {
            v.setViewVisibility(R.id.metaBox, View.VISIBLE); v.setTextColor(R.id.metaSub, sub);
            JSONObject g = goalFor(p, d.optString("goalId", ""));
            if (g == null) { v.setTextViewText(R.id.metaSub, "Crie uma meta no app primeiro."); v.setProgressBar(R.id.metaBar, 100, 0, false); }
            else {
                int pct = g.optInt("pct", 0);
                v.setProgressBar(R.id.metaBar, 100, pct, false);
                String val = g.optBoolean("money", false)
                        ? ("R$ " + g.optInt("cur", 0) + " / R$ " + g.optInt("target", 0))
                        : (g.optInt("cur", 0) + "/" + g.optInt("target", 0) + " " + g.optString("scope", ""));
                v.setTextViewText(R.id.metaSub, val + " · " + pct + "%");
                v.setTextViewText(R.id.wTitle, (icon.isEmpty() ? "🎯 " : icon + " ") + g.optString("name", name));
            }

        } else if ("contador".equals(type)) {
            v.setViewVisibility(R.id.cntBox, View.VISIBLE);
            v.setTextColor(R.id.cntBig, accent); v.setTextColor(R.id.cntLabel, sub);
            int cnt = p.getInt("cnt_" + widgetId, 0);
            v.setTextViewText(R.id.cntBig, String.valueOf(cnt));
            v.setTextViewText(R.id.cntLabel, d.optString("counterLabel", "toque em + para somar"));
            Intent ci = new Intent(c, CustomWidget.class); ci.setAction(ACTION_CNT); ci.putExtra("wid", widgetId);
            v.setOnClickPendingIntent(R.id.cntPlus, PendingIntent.getBroadcast(c, ("cnt" + widgetId).hashCode(), ci, Widgets.piFlags()));

        } else if ("conquistas".equals(type)) {
            v.setViewVisibility(R.id.twoBox, View.VISIBLE);
            v.setTextColor(R.id.tbBig0, accent); v.setTextColor(R.id.tbBig1, accent);
            v.setTextColor(R.id.tbSub0, sub); v.setTextColor(R.id.tbSub1, sub);
            v.setTextViewText(R.id.tbBig0, "🏆 " + p.getInt("trophies", 0)); v.setTextViewText(R.id.tbSub0, "troféus");
            v.setTextViewText(R.id.tbBig1, "Nv " + p.getInt("level", 1)); v.setTextViewText(R.id.tbSub1, "nível");

        } else if ("shortcuts".equals(type)) {
            v.setViewVisibility(R.id.scBox, View.VISIBLE);
            JSONArray sc = d.optJSONArray("shortcuts"); if (sc == null) sc = new JSONArray();
            for (int i = 0; i < SC.length; i++) {
                if (i < sc.length()) {
                    String key = sc.optString(i);
                    v.setViewVisibility(SC[i], View.VISIBLE);
                    v.setInt(SC[i], "setBackgroundResource", night ? R.drawable.chip_dark : R.drawable.chip_light);
                    v.setTextViewText(SCI[i], scEmoji(key)); v.setTextViewText(SCT[i], scLabel(key)); v.setTextColor(SCT[i], text);
                    v.setOnClickPendingIntent(SC[i], Widgets.openAction(c, key, 8700 + widgetId % 200 * 10 + i));
                } else v.setViewVisibility(SC[i], View.GONE);
            }

        } else {
            // checklist / list / agenda -> lista ROLÁVEL (ListView + serviço), mostra todos os itens
            v.setViewVisibility(R.id.linesBox, View.VISIBLE);
            boolean isCheck = "checklist".equals(type);
            if (isCheck) {
                int[] dt = doneTotal(p, d, source);
                if (dt[1] > 0) { v.setViewVisibility(R.id.wCount, View.VISIBLE); v.setTextViewText(R.id.wCount, dt[0] + "/" + dt[1]); }
            }
            Intent svc = new Intent(c, CustomListService.class);
            svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            svc.setData(Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME)));
            v.setRemoteAdapter(R.id.lvList, svc);
            v.setEmptyView(R.id.lvList, R.id.lvEmpty);
            v.setTextColor(R.id.lvEmpty, sub);
            v.setTextViewText(R.id.lvEmpty, "agenda".equals(type) ? "Sem eventos próximos" : "Sem itens ainda");
            Intent tpl = new Intent(c, CustomWidget.class); tpl.setAction(ACTION_ROW); tpl.putExtra("wid", widgetId);
            int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            v.setPendingIntentTemplate(R.id.lvList, PendingIntent.getBroadcast(c, ("row" + widgetId).hashCode(), tpl, fl));
            listWidget = true;
            if (d.optBoolean("addBtn", false) && !"agenda".equals(type)) {
                v.setViewVisibility(R.id.wAdd, View.VISIBLE); v.setTextColor(R.id.wAdd, accent);
                String addAct = "reminders".equals(source) ? "reminder" : "wishes".equals(source) ? "wish" : "routines".equals(source) ? "routine" : "hoje";
                v.setOnClickPendingIntent(R.id.wAdd, Widgets.openAction(c, addAct, 8900 + widgetId % 300));
            }


            // faixa de atalhos no rodapé
            if (d.optBoolean("withShortcuts", false)) {
                JSONArray sc = d.optJSONArray("shortcuts"); if (sc == null) sc = new JSONArray();
                v.setViewVisibility(R.id.stripBox, View.VISIBLE);
                for (int i = 0; i < ST.length; i++) {
                    if (i < sc.length()) {
                        String key = sc.optString(i);
                        v.setViewVisibility(ST[i], View.VISIBLE);
                        v.setInt(ST[i], "setBackgroundResource", night ? R.drawable.chip_dark : R.drawable.chip_light);
                        v.setTextViewText(STI[i], scEmoji(key)); v.setTextViewText(STT[i], scLabel(key)); v.setTextColor(STT[i], text);
                        v.setOnClickPendingIntent(ST[i], Widgets.openAction(c, key, 8750 + widgetId % 200 * 10 + i));
                    } else v.setViewVisibility(ST[i], View.GONE);
                }
            }
        }
        m.updateAppWidget(widgetId, v);
        if (listWidget) m.notifyAppWidgetViewDataChanged(widgetId, R.id.lvList);
    }

    static int[] doneTotal(SharedPreferences p, JSONObject d, String source) {
        JSONArray items = itemsFor(p, d, source); int dn = 0;
        for (int i = 0; i < items.length(); i++) { JSONObject it = items.optJSONObject(i); if (it != null && it.optBoolean("done", false)) dn++; }
        return new int[]{ dn, items.length() };
    }

    /** Monta todas as linhas da lista: k = "h" (período), "c" (Concluídas), "i" (item). */
    static ArrayList<JSONObject> buildCells(Context c, int widgetId) {
        ArrayList<JSONObject> cells = new ArrayList<>();
        try {
            SharedPreferences p = Widgets.prefs(c);
            JSONObject d = designFor(c, widgetId); if (d == null) return cells;
            String type = d.optString("type", "list"), source = d.optString("source", "routines");
            String scr = "reminders".equals(source) ? "lembretes" : "wishes".equals(source) ? "desejos" : "hoje";
            if ("agenda".equals(type)) {
                JSONArray ag = new JSONArray(p.getString("agenda", "[]"));
                for (int i = 0; i < ag.length(); i++) {
                    JSONObject e = ag.optJSONObject(i); if (e == null) continue;
                    String date = e.optString("date", "");
                    String dtxt = date.length() >= 10 ? (date.substring(8, 10) + "/" + date.substring(5, 7)) : "";
                    JSONObject o = new JSONObject(); o.put("k", "i"); o.put("mark", e.optString("emoji", "📅"));
                    o.put("text", e.optString("name", "") + (dtxt.isEmpty() ? "" : "  ·  " + dtxt)); o.put("act", "open"); o.put("scr", "hoje");
                    cells.add(o);
                }
                return cells;
            }
            boolean isCheck = "checklist".equals(type);
            boolean group = d.optBoolean("group", false) && "routines".equals(source);
            boolean hide = isCheck && "hide".equals(d.optString("doneMode", "strike"));
            boolean expanded = p.getBoolean("exp_" + widgetId, false);
            JSONArray items = itemsFor(p, d, source);
            ArrayList<JSONObject> main = new ArrayList<>(), doneL = new ArrayList<>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i); if (it == null) continue;
                boolean dn = it.optBoolean("done", false);
                if (dn) doneL.add(it);
                if (!(isCheck && dn)) main.add(it); // checklist: concluídas saem da lista principal
            }
            if (group) {
                LinkedHashMap<String, ArrayList<JSONObject>> gr = new LinkedHashMap<>();
                gr.put("🌅 Manhã", new ArrayList<>()); gr.put("☀️ Tarde", new ArrayList<>()); gr.put("🌙 Noite", new ArrayList<>()); gr.put("🕓 Sem horário", new ArrayList<>());
                for (JSONObject it : main) { ArrayList<JSONObject> b = gr.get(periodLabel(it.optString("time", ""))); if (b != null) b.add(it); }
                for (String L : gr.keySet()) {
                    ArrayList<JSONObject> bl = gr.get(L); if (bl == null || bl.isEmpty()) continue;
                    JSONObject h = new JSONObject(); h.put("k", "h"); h.put("text", L); cells.add(h);
                    for (JSONObject it : bl) cells.add(itemCell(it, isCheck, source, scr));
                }
            } else {
                for (JSONObject it : main) cells.add(itemCell(it, isCheck, source, scr));
            }
            if (isCheck && !hide && !doneL.isEmpty()) { // modo "riscar": concluídas vão para a aba recolhível
                JSONObject h = new JSONObject(); h.put("k", "c"); h.put("text", (expanded ? "▾" : "▸") + "  ✓ Concluídas (" + doneL.size() + ")"); h.put("act", "exp"); cells.add(h);
                if (expanded) for (JSONObject it : doneL) cells.add(itemCell(it, true, source, scr));
            }
        } catch (Exception ignored) {}
        return cells;
    }

    static JSONObject itemCell(JSONObject it, boolean isCheck, String source, String scr) throws org.json.JSONException {
        boolean dn = it.optBoolean("done", false); String rid = it.optString("id", ""), emoji = it.optString("emoji", "");
        JSONObject o = new JSONObject(); o.put("k", "i"); o.put("done", dn);
        o.put("text", (emoji.isEmpty() ? "" : emoji + " ") + it.optString("name", ""));
        o.put("mark", isCheck ? (dn ? "☑" : "☐") : "•"); o.put("chk", isCheck);
        if (isCheck && "routines".equals(source) && !rid.isEmpty()) { o.put("act", "toggle"); o.put("rid", rid); o.put("want", !dn); }
        else { o.put("act", "open"); o.put("scr", scr); }
        return o;
    }

    static ArrayList<JSONObject> orderList(JSONArray items) {
        ArrayList<JSONObject> out = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) { JSONObject it = items.optJSONObject(i); if (it != null) out.add(it); }
        return out;
    }

    static String periodLabel(String time) {
        if (time == null || time.isEmpty()) return "🕓 Sem horário";
        try { int h = Integer.parseInt(time.split(":")[0]); if (h < 12) return "🌅 Manhã"; if (h < 18) return "☀️ Tarde"; return "🌙 Noite"; } catch (Exception e) { return "🕓 Sem horário"; }
    }

    private JSONObject goalFor(SharedPreferences p, String goalId) {
        try {
            JSONArray a = new JSONArray(p.getString("goals", "[]"));
            if (a.length() == 0) return null;
            if (goalId != null && !goalId.isEmpty()) for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && goalId.equals(o.optString("id"))) return o; }
            return a.optJSONObject(0);
        } catch (Exception e) { return null; }
    }

    static JSONArray itemsFor(SharedPreferences p, JSONObject d, String source) {
        try {
            if ("custom".equals(source)) {
                JSONArray lines = d.optJSONArray("lines"); if (lines == null) return new JSONArray();
                JSONArray out = new JSONArray();
                for (int i = 0; i < lines.length(); i++) { JSONObject l = lines.optJSONObject(i); if (l == null) continue; JSONObject o = new JSONObject(); o.put("name", l.optString("text", "")); o.put("emoji", l.optString("icon", "")); o.put("done", l.optBoolean("done", false)); out.put(o); }
                return out;
            }
            if ("reminders".equals(source)) return mapField(p.getString("reminders", "[]"), "text", "🔔");
            if ("wishes".equals(source)) return mapField(p.getString("wishes", "[]"), "name", "🛒");
            return new JSONArray(p.getString("routines", "[]"));
        } catch (Exception e) { return new JSONArray(); }
    }
    static JSONArray mapField(String raw, String field, String emoji) {
        JSONArray out = new JSONArray();
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o == null) continue; JSONObject n = new JSONObject(); n.put("name", o.optString(field, "")); n.put("emoji", emoji); out.put(n); } } catch (Exception ignored) {}
        return out;
    }
    private String statValue(SharedPreferences p, String kind) {
        if ("progress".equals(kind)) return p.getInt("pct", 0) + "%";
        if ("streak".equals(kind)) return "🔥 " + p.getInt("streak", 0);
        if ("coins".equals(kind)) return "🪙 " + p.getInt("coins", 0);
        if ("level".equals(kind)) return "Nv " + p.getInt("level", 1);
        if ("spend".equals(kind)) return "R$ " + p.getInt("spendToday", 0);
        return "";
    }
    private String statLabel(String kind) {
        if ("progress".equals(kind)) return "progresso de hoje";
        if ("streak".equals(kind)) return "sequência";
        if ("coins".equals(kind)) return "moedas do guerreiro";
        if ("level".equals(kind)) return "nível";
        if ("spend".equals(kind)) return "gasto de hoje";
        return "";
    }
    private String finValue(SharedPreferences p, String fk) {
        if ("spend".equals(fk)) return "R$ " + p.getInt("spendToday", 0);
        if ("receitas".equals(fk)) return "R$ " + p.getInt("finReceitas", 0);
        if ("despesas".equals(fk)) return "R$ " + p.getInt("finDespesas", 0);
        return "R$ " + p.getInt("finSaldo", 0);
    }
    private String finLabel(String fk) {
        if ("spend".equals(fk)) return "gasto de hoje";
        if ("receitas".equals(fk)) return "receitas do mês";
        if ("despesas".equals(fk)) return "despesas do mês";
        return "saldo do mês";
    }
    private String scEmoji(String k) {
        switch (k) { case "routine": return "✅"; case "wish": return "🛒"; case "expense": return "💸"; case "expense_card": return "💳"; case "reminder": return "🔔"; case "note": return "📝"; case "pontos": return "🏆"; default: return "🏠"; }
    }
    private String scLabel(String k) {
        switch (k) { case "routine": return "Rotina"; case "wish": return "Desejo"; case "expense": return "Despesa"; case "expense_card": return "Cartão"; case "reminder": return "Lembrete"; case "note": return "Nota"; case "pontos": return "Pontos"; default: return "Hoje"; }
    }
}
