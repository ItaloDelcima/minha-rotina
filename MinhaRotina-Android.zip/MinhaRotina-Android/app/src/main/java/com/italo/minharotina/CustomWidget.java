package com.italo.minharotina;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

public class CustomWidget extends AppWidgetProvider {
    static final String ACTION_TOGGLE = "com.italo.minharotina.CW_TOGGLE";
    private static final int[] LROW = { R.id.lrow0, R.id.lrow1, R.id.lrow2, R.id.lrow3, R.id.lrow4, R.id.lrow5, R.id.lrow6, R.id.lrow7 };
    private static final int[] LCHK = { R.id.lchk0, R.id.lchk1, R.id.lchk2, R.id.lchk3, R.id.lchk4, R.id.lchk5, R.id.lchk6, R.id.lchk7 };
    private static final int[] LNAME = { R.id.lname0, R.id.lname1, R.id.lname2, R.id.lname3, R.id.lname4, R.id.lname5, R.id.lname6, R.id.lname7 };
    private static final int[] SC = { R.id.sc0, R.id.sc1, R.id.sc2, R.id.sc3, R.id.sc4, R.id.sc5 };
    private static final int[] SCI = { R.id.sc0i, R.id.sc1i, R.id.sc2i, R.id.sc3i, R.id.sc4i, R.id.sc5i };
    private static final int[] SCT = { R.id.sc0t, R.id.sc1t, R.id.sc2t, R.id.sc3t, R.id.sc4t, R.id.sc5t };

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) render(c, m, id); }

    @Override public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = Widgets.prefs(c).edit();
        for (int id : ids) e.remove("cfg_" + id);
        e.apply();
    }

    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            String rid = intent.getStringExtra("rid");
            boolean want = intent.getBooleanExtra("want", true);
            if (rid != null) { toggleRoutine(c, rid, want); Widgets.updateAll(c); }
        }
    }

    private void toggleRoutine(Context c, String rid, boolean want) {
        SharedPreferences p = Widgets.prefs(c);
        try {
            JSONArray arr = new JSONArray(p.getString("routines", "[]"));
            for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && rid.equals(o.optString("id"))) { o.put("done", want); break; } }
            JSONArray pend = new JSONArray(p.getString("pending", "[]")); JSONArray next = new JSONArray();
            for (int i = 0; i < pend.length(); i++) { JSONObject o = pend.optJSONObject(i); if (o != null && !rid.equals(o.optString("id"))) next.put(o); }
            JSONObject nw = new JSONObject(); nw.put("id", rid); nw.put("done", want); next.put(nw);
            p.edit().putString("routines", arr.toString()).putString("pending", next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static JSONObject designFor(Context c, int widgetId) {
        SharedPreferences p = Widgets.prefs(c);
        String did = p.getString("cfg_" + widgetId, "");
        try {
            JSONArray arr = new JSONArray(p.getString("customWidgets", "[]"));
            if (!did.isEmpty()) for (int i = 0; i < arr.length(); i++) { JSONObject o = arr.optJSONObject(i); if (o != null && did.equals(o.optString("id"))) return o; }
            if (arr.length() > 0) return arr.optJSONObject(0);
        } catch (Exception ignored) {}
        return null;
    }

    static boolean night(Context c, JSONObject d) {
        String m = d != null ? d.optString("theme", "system") : "system";
        if ("light".equals(m)) return false;
        if ("dark".equals(m)) return true;
        int f = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return f == Configuration.UI_MODE_NIGHT_YES;
    }
    static int accentOf(Context c, JSONObject d) {
        if (d != null) { String col = d.optString("color", "accent"); if (!"accent".equals(col)) { try { return Color.parseColor(col); } catch (Exception e) {} } }
        return Widgets.accent(c);
    }

    private void render(Context c, AppWidgetManager m, int widgetId) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_custom);
        JSONObject d = designFor(c, widgetId);
        boolean night = night(c, d);
        int text = night ? 0xFFF2F2F5 : 0xFF1A1A1E, sub = night ? 0xFFAFAFB8 : 0xFF6A6A72, accent = accentOf(c, d);
        v.setInt(R.id.root, "setBackgroundResource", night ? R.drawable.bg_widget_dark : R.drawable.bg_widget_light);
        v.setTextColor(R.id.wTitle, text); v.setTextColor(R.id.wCount, accent);
        v.setViewVisibility(R.id.statBox, View.GONE); v.setViewVisibility(R.id.wPhrase, View.GONE);
        v.setViewVisibility(R.id.linesBox, View.GONE); v.setViewVisibility(R.id.scBox, View.GONE);
        v.setViewVisibility(R.id.wCount, View.GONE); v.setViewVisibility(R.id.wAdd, View.GONE);

        if (d == null) {
            v.setTextViewText(R.id.wTitle, "Widget Trem Bão");
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, sub);
            v.setTextViewText(R.id.wPhrase, "Abra o app › Widgets para criar um modelo.");
            v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, "widgets", 8600 + (widgetId % 300)));
            m.updateAppWidget(widgetId, v); return;
        }

        String type = d.optString("type", "list"), name = d.optString("name", "Widget"), icon = d.optString("icon", ""), source = d.optString("source", "routines");
        v.setTextViewText(R.id.wTitle, (icon.isEmpty() ? "" : icon + " ") + name);
        String openScr = "stat".equals(type) ? "pontos" : "reminders".equals(source) ? "lembretes" : "wishes".equals(source) ? "desejos" : "hoje";
        v.setOnClickPendingIntent(R.id.headerRow, Widgets.openAction(c, openScr, 8600 + (widgetId % 300)));

        SharedPreferences p = Widgets.prefs(c);
        if ("stat".equals(type)) {
            v.setViewVisibility(R.id.statBox, View.VISIBLE);
            v.setTextColor(R.id.wStatBig, accent); v.setTextColor(R.id.wStatSub, sub);
            String kind = d.optString("statKind", "progress");
            v.setTextViewText(R.id.wStatBig, statValue(p, kind));
            v.setTextViewText(R.id.wStatSub, statLabel(kind));
        } else if ("phrase".equals(type)) {
            v.setViewVisibility(R.id.wPhrase, View.VISIBLE); v.setTextColor(R.id.wPhrase, accent);
            String ph = d.optString("phrase", "").trim();
            if (ph.isEmpty()) ph = p.getString("phrase", "Bora, guerreiro! 🤠");
            v.setTextViewText(R.id.wPhrase, ph);
        } else if ("shortcuts".equals(type)) {
            v.setViewVisibility(R.id.scBox, View.VISIBLE);
            JSONArray sc = d.optJSONArray("shortcuts"); if (sc == null) sc = new JSONArray();
            for (int i = 0; i < SC.length; i++) {
                if (i < sc.length()) {
                    String key = sc.optString(i);
                    v.setViewVisibility(SC[i], View.VISIBLE);
                    v.setInt(SC[i], "setBackgroundResource", night ? R.drawable.chip_dark : R.drawable.chip_light);
                    v.setTextViewText(SCI[i], scEmoji(key)); v.setTextViewText(SCT[i], scLabel(key)); v.setTextColor(SCT[i], text);
                    v.setOnClickPendingIntent(SC[i], Widgets.openAction(c, key, 8700 + widgetId % 200 * 10 + i));
                } else v.setViewVisibility(SC[i], View.GONE);
            }
        } else {
            v.setViewVisibility(R.id.linesBox, View.VISIBLE);
            boolean isCheck = "checklist".equals(type);
            JSONArray items = itemsFor(p, d, source);
            int shown = Math.min(items.length(), LROW.length), done = 0;
            for (int i = 0; i < LROW.length; i++) {
                if (i < shown) {
                    JSONObject it = items.optJSONObject(i); if (it == null) it = new JSONObject();
                    String emoji = it.optString("emoji", ""), nm = it.optString("name", "");
                    boolean dn = it.optBoolean("done", false); String rid = it.optString("id", "");
                    v.setViewVisibility(LROW[i], View.VISIBLE);
                    v.setTextViewText(LNAME[i], (emoji.isEmpty() ? "" : emoji + " ") + nm);
                    v.setTextColor(LNAME[i], dn ? sub : text);
                    if (isCheck) {
                        v.setTextViewText(LCHK[i], dn ? "☑" : "☐");
                        v.setTextColor(LCHK[i], dn ? accent : sub);
                        if ("routines".equals(source) && !rid.isEmpty()) {
                            Intent t = new Intent(c, CustomWidget.class); t.setAction(ACTION_TOGGLE); t.putExtra("rid", rid); t.putExtra("want", !dn);
                            v.setOnClickPendingIntent(LROW[i], PendingIntent.getBroadcast(c, ("cw" + widgetId + rid).hashCode(), t, Widgets.piFlags()));
                        } else {
                            v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, openScr, 8800 + widgetId % 200 * 10 + i));
                        }
                    } else {
                        v.setTextViewText(LCHK[i], "•"); v.setTextColor(LCHK[i], accent);
                        v.setOnClickPendingIntent(LROW[i], Widgets.openAction(c, openScr, 8800 + widgetId % 200 * 10 + i));
                    }
                    if (dn) done++;
                } else v.setViewVisibility(LROW[i], View.GONE);
            }
            if (isCheck && shown > 0) { v.setViewVisibility(R.id.wCount, View.VISIBLE); v.setTextViewText(R.id.wCount, done + "/" + shown); }
            if (d.optBoolean("addBtn", false)) {
                v.setViewVisibility(R.id.wAdd, View.VISIBLE); v.setTextColor(R.id.wAdd, accent);
                String addAct = "reminders".equals(source) ? "reminder" : "wishes".equals(source) ? "wish" : "routines".equals(source) ? "routine" : "hoje";
                v.setOnClickPendingIntent(R.id.wAdd, Widgets.openAction(c, addAct, 8900 + widgetId % 300));
            }
        }
        m.updateAppWidget(widgetId, v);
    }

    private JSONArray itemsFor(SharedPreferences p, JSONObject d, String source) {
        try {
            if ("custom".equals(source)) {
                JSONArray lines = d.optJSONArray("lines"); if (lines == null) return new JSONArray();
                JSONArray out = new JSONArray();
                for (int i = 0; i < lines.length(); i++) { JSONObject l = lines.optJSONObject(i); if (l == null) continue; JSONObject o = new JSONObject(); o.put("name", l.optString("text", "")); o.put("emoji", l.optString("icon", "")); o.put("done", l.optBoolean("done", false)); out.put(o); }
                return out;
            }
            if ("reminders".equals(source)) return mapField(p.getString("reminders", "[]"), "text");
            if ("wishes".equals(source)) return mapField(p.getString("wishes", "[]"), "name");
            return new JSONArray(p.getString("routines", "[]"));
        } catch (Exception e) { return new JSONArray(); }
    }
    private JSONArray mapField(String raw, String field) {
        JSONArray out = new JSONArray();
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o == null) continue; JSONObject n = new JSONObject(); n.put("name", o.optString(field, "")); out.put(n); } } catch (Exception ignored) {}
        return out;
    }
    private String statValue(SharedPreferences p, String kind) {
        if ("progress".equals(kind)) return p.getInt("pct", 0) + "%";
        if ("streak".equals(kind)) return "🔥 " + p.getInt("streak", 0);
        if ("coins".equals(kind)) return "🪙 " + p.getInt("coins", 0);
        if ("level".equals(kind)) return "Nv " + p.getInt("level", 1);
        if ("spend".equals(kind)) return "R$ " + p.getInt("spendToday", 0);
        return "";
    }
    private String statLabel(String kind) {
        if ("progress".equals(kind)) return "progresso de hoje";
        if ("streak".equals(kind)) return "sequência";
        if ("coins".equals(kind)) return "moedas do guerreiro";
        if ("level".equals(kind)) return "nível";
        if ("spend".equals(kind)) return "gasto de hoje";
        return "";
    }
    private String scEmoji(String k) {
        switch (k) { case "routine": return "✅"; case "wish": return "🛒"; case "expense": return "💸"; case "expense_card": return "💳"; case "reminder": return "🔔"; case "note": return "📝"; case "pontos": return "🏆"; default: return "🏠"; }
    }
    private String scLabel(String k) {
        switch (k) { case "routine": return "Rotina"; case "wish": return "Desejo"; case "expense": return "Despesa"; case "expense_card": return "Cartão"; case "reminder": return "Lembrete"; case "note": return "Nota"; case "pontos": return "Pontos"; default: return "Hoje"; }
    }
}
