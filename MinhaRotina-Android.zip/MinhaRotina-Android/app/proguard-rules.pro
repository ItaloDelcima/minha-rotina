# Mantém a WebView e a interface JS
-keep class android.webkit.** { *; }
