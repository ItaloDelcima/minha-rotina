# Minha Rotina 🔥

App Android de rotina diária, metas semanais/mensais e pontuação gamificada.
Tema laranja, modo claro/escuro, navegação inferior. Funciona 100% offline
(dados salvos no aparelho via WebView + localStorage).

## Como gerar o APK
Veja o passo a passo em **GUIA-INSTALACAO.md**. Caminho mais fácil: subir esta
pasta para um repositório no GitHub — o workflow em `.github/workflows/build-apk.yml`
compila o `.apk` automaticamente e disponibiliza para download na aba **Actions**.

## Estrutura
- `app/src/main/assets/index.html` — o app inteiro (interface + lógica).
- `app/src/main/java/.../MainActivity.java` — WebView que carrega o app.
- `app/src/main/res/` — ícones, tema e strings.

## Build local
Requer Android Studio (ou SDK + JDK 17). Rode:
```
./gradlew assembleDebug
```
APK gerado em `app/build/outputs/apk/debug/app-debug.apk`.
