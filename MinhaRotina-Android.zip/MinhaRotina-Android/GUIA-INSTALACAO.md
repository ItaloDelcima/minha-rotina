# 📱 Minha Rotina — Guia de Instalação (Samsung S22)

Este é o app de rotina, metas e pontuação que criamos para você. Este guia mostra **3 formas** de colocar ele no seu celular, da mais fácil para a mais técnica.

---

## ✅ Opção 1 (mais fácil): gerar o `.apk` na nuvem pelo GitHub — sem instalar nada no PC

Você não precisa instalar programa nenhum. O GitHub compila o app para você e te dá o arquivo `.apk` pronto para baixar.

1. Crie uma conta gratuita em **https://github.com** (se ainda não tiver).
2. Clique em **New repository** (novo repositório), dê o nome `minha-rotina`, deixe **Public** ou **Private**, e clique em **Create repository**.
3. Na página do repositório, clique em **"uploading an existing file"** (ou **Add file → Upload files**).
4. **Arraste para lá TODO o conteúdo desta pasta** (a pasta `MinhaRotina-Android` inteira — pode arrastar todos os arquivos e subpastas de uma vez). Clique em **Commit changes**.
5. Vá na aba **Actions** (no topo do repositório). Vai aparecer um processo chamado **"Gerar APK"** rodando. Espere ele terminar (leva ~2 a 4 minutos e fica com um ✅ verde).
6. Clique no processo concluído. Na parte de baixo, em **Artifacts**, clique em **`MinhaRotina-apk`** para baixar um `.zip`.
7. Abra o `.zip` — dentro está o arquivo **`app-debug.apk`**. Esse é o seu app!
8. Passe esse `.apk` para o celular (WhatsApp para você mesmo, Google Drive, cabo USB, etc.) e siga a seção **"Instalando o APK no S22"** abaixo.

> Dica: sempre que quisermos mudar algo no app, é só subir o arquivo novo e o GitHub gera um `.apk` atualizado automaticamente.

---

## 🛠️ Opção 2: compilar no seu computador com o Android Studio

Para quem prefere fazer local ou quer mexer no código.

1. Baixe e instale o **Android Studio**: https://developer.android.com/studio
2. Abra o Android Studio → **Open** → selecione a pasta `MinhaRotina-Android`.
3. Espere ele baixar as dependências (barra de progresso embaixo; primeira vez demora).
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Quando terminar, aparece um aviso **"locate"** — clique para achar o `app-debug.apk` (fica em `app/build/outputs/apk/debug/`).
6. Passe para o celular e instale (seção abaixo).

Para conectar o celular por cabo e instalar direto: ative a **Depuração USB** no S22 (Configurações → Sobre o telefone → Informações do software → toque 7x em "Número da versão" para liberar o modo desenvolvedor), conecte o cabo e clique no botão ▶️ **Run** no Android Studio.

---

## 📥 Instalando o APK no S22

1. Copie o arquivo `app-debug.apk` para o celular.
2. Abra o arquivo pelo gerenciador de arquivos (app **Meus Arquivos** da Samsung).
3. O Android vai avisar que precisa permitir instalar de fontes desconhecidas → toque em **Configurações** → ative **"Permitir desta fonte"**.
4. Volte e toque em **Instalar**.
5. Pronto! O ícone laranja **Minha Rotina** aparece na sua tela inicial. 🔥

> É um app normal, funciona **100% offline**, e seus dados ficam salvos no próprio aparelho.

---

## 🚀 Opção 3: usar AGORA como atalho (enquanto não gera o APK)

Se quiser testar na hora, sem esperar: abra o arquivo `index.html` (dentro de `app/src/main/assets/`) no **Chrome** do celular, toque no menu **⋮ → Adicionar à tela inicial**. Ele vira um atalho e funciona igual. (Recomendo migrar para o `.apk` depois, pois é mais estável para guardar os dados.)

---

## 🎮 Como usar o app

**Aba Hoje** — sua rotina do dia. Toque no círculo ✓ para marcar como feito (ganha pontos e anima 🎉). Tudo **reinicia sozinho à meia-noite**, mas o histórico é guardado. Toque no nome de uma rotina para editar.

**Aba Metas** — suas metas semanais e mensais com barras de progresso. Cada rotina/atividade vinculada a uma meta alimenta a barra automaticamente. As **metas financeiras (R$)** aparecem aqui com o botão **＋ Adicionar valor** para registrar aportes. Também aparecem as **atividades registradas** (ex: "almocei fora").

**Aba Pontos** — pontuação total, por hoje/semana/mês, nível/XP, **gráficos de evolução**, distribuição dos pontos (inclusive **penalidades**) e conquistas.

**Aba Desejos 🛒** — sua lista de compras organizada por **categoria** (ex: Casa, Carro, Eletrônicos), com preço estimado, prioridade e o círculo ✓ para marcar como comprado. O cabeçalho mostra o total estimado do que falta comprar.

**Botão ＋ (centro)** — adicionar **Rotina**, **Meta**, **Meta Financeira (R$)**, **Atividade**, **registrar uma atividade feita agora** ou **Novo Desejo/Compra**.

**Metas de Atingir x Limite** — ao criar uma meta você escolhe a direção: **Atingir** (fazer no mínimo X — ganha pontos ao bater) ou **Limite** (não passar de X — se ultrapassar, perde pontos e o gráfico marca negativo). Ex: "Restaurante no máx. 1x/semana": se você registrar a atividade Restaurante 2x, o limite estoura e desconta pontos. Rotinas e atividades podem ser vinculadas a qualquer meta.

**Histórico 📅** — agora fica no ícone de calendário no topo de cada tela.

**Horários e lembretes** — ao criar uma rotina você pode definir um horário; o dia se organiza em Manhã/Tarde/Noite. Em **⚙️ Configurações → Lembretes por horário** você liga os avisos (funcionam com o app aberto).

**Aba Histórico** — seus últimos 30 dias de conclusões.

### Pontuação
- Rotina concluída: **+10**
- Atividade cadastrada registrada: **+10** (atividades não cadastradas ficam no histórico mas **não pontuam**)
- Meta semanal cumprida: **+20**
- Meta mensal cumprida: **+30**

(Os valores são configuráveis em **⚙️ Configurações**.)

### ⚠️ Backup dos seus dados (importante)
Como os dados ficam no aparelho, em **⚙️ Configurações → Backup** você pode **Exportar** (copiar um texto) e **Importar** para restaurar. Faça isso de vez em quando, e sempre antes de trocar de celular.

---

## 💡 Sugestões do programador (melhorias que valem a pena)

Coisas que já deixei prontas e não estavam no pedido original:
- **Sequências (streaks) 🔥** por hábito — motiva a não quebrar a corrente.
- **Nível e XP** como no jogo da sua referência.
- **Vínculo rotina ↔ meta** (você pediu) + atividades também podem alimentar metas.
- **Metas financeiras (R$)** — defina um alvo mensal em reais e registre os aportes; a barra enche em reais e você pontua ao bater a meta.
- **Metas positivas e negativas** — metas de atingir (mínimo) e de limite (máximo, com penalidade ao estourar) e **recompensa por respeitar o limite** ao fim da semana/mês.
- **Extrato financeiro** — em cada meta financeira, botão “📄 Extrato” com histórico de aportes e gráfico de R$ por mês.
- **Categorias com cores nas rotinas e atividades** (Saúde, Atividade, Alimentação, Financeira, etc.).
- **Resumo financeiro geral** na aba Metas, somando as metas de guardar (guardado no mês e acumulado total).
- **Meta financeira de limite de gasto** — além de “guardar”, dá pra criar um teto de gasto mensal em R$ (penalidade se passar, recompensa se respeitar).
- **Resumo do dia** na tela inicial (barra “X% do dia concluído”).
- **Desejos com categorias coloridas**, além de **ordenar** (categoria/prioridade/preço) e **ocultar comprados**.
- **Editar atividade pelo histórico** (toque no item em “Atividades recentes”), e seção **“Atividades cadastradas”** para editar/excluir.
- **Metas de tempo** (minutos por semana/mês) com registro rápido (+15/+30/+60).
- **Desejos somados no resumo** (total por categoria e no resumo financeiro) e botão para **transformar um desejo em meta de guardar**.
- **Reordenar rotinas** (botão ⇅ Reordenar, com setas) e **duplicar** rotina.
- **Backup por compartilhamento** (⚙️ Configurações → Compartilhar/salvar backup) usando o menu do celular.
- **Ícone (emoji) por rotina** com atalhos, mostrado num círculo no card.
- **Dias da semana por rotina** — a rotina só aparece nos dias escolhidos, e os dias de folga não quebram a sequência.
- **Confirmação antes de excluir** rotina, meta e desejo.
- **Corrigir dias anteriores**: no Histórico 📅, toque num dia para marcar/desmarcar o que esqueceu.
- **Recorde de melhor sequência** por rotina (aba Pontos).
- **Filtrar metas por tipo** (hábito, limite, financeira, tempo).
- **Cor de destaque** escolhível nas Configurações (laranja e outras).
- **Nota do dia** (diário curto) na aba Hoje e no histórico.
- **Rotina de medição** (ex: Pesar): ao concluir, o app pede um valor (peso), guarda por data e mostra um **gráfico de evolução** (toque no 📈 no card). Ative em uma rotina com “Registrar um valor ao concluir”.
- **Reordenar rotinas**: na aba Hoje, botão **⇅ Reordenar** troca os círculos por setas ↑ ↓ para mover cada rotina.
- **Pontos e penalidades ajustáveis** em ⚙️ Configurações, e também **por meta** (cada meta pode ter pontos/penalidade próprios).
- **Aba Desejos/Compras** — lista do que você quer comprar, por categoria, com preço e prioridade.
- **Gráficos de evolução** (na aba Pontos): pontos dos últimos 14 dias (com barras negativas quando há penalidade), rotinas concluídas na semana e a taxa de conclusão dos últimos 30 dias.
- **Horário por rotina** com agrupamento em **Manhã / Tarde / Noite**, e **lembretes** nos horários (com o app aberto — em ⚙️ Configurações).
- **Backup exportar/importar** — essencial, já que os dados são locais.
- **Histórico de 30 dias** e **conquistas**.
- **Modo claro/escuro** e início de semana configurável (seg/dom).

Ideias para as próximas versões (é só pedir):
1. **Notificações mesmo com o app fechado** — hoje o lembrete toca com o app aberto; para tocar sempre, dá pra adicionar um módulo nativo de alarmes no Android.
2. **Sincronização na nuvem** (ex: sua conta Google) para não depender de backup manual e usar em vários aparelhos.
3. **Categorias com cores** (Saúde, Financeira, Atividade) — desativamos por enquanto, mas dá pra ligar depois.
4. **Extrato financeiro** com histórico de aportes por meta e gráfico de reais por mês.
5. **Metas de tempo** (ex: 150 min de exercício por semana).

---

Qualquer coisa que quiser mudar (cores, textos, pontuação, novas telas), é só me falar que eu ajusto. 🧡
